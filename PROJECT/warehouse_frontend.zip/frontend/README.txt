FRONTEND
HTML, CSS and JavaScript files for the Warehouse Management System.

Open index.html to start the frontend.
