// ============================================================
// INVENTORY & WAREHOUSE MANAGEMENT SYSTEM
// FRONTEND ONLY - NEW SCRIPT
// ============================================================


// ============================================================
// 1. ROLE SELECTION
// ============================================================

function openAdminLogin() {
    window.location.href = "adminlogin.html";
}

function openStaffLogin() {
    window.location.href = "stafflogin.html";
}

function goHome() {
    window.location.href = "index.html";
}


// ============================================================
// 2. PASSWORD SHOW / HIDE
// ============================================================

function toggleAdminPassword() {
    const password = document.getElementById("adminPassword");

    if (!password) return;

    password.type =
        password.type === "password"
            ? "text"
            : "password";
}

function toggleStaffPassword() {
    const password = document.getElementById("staffPassword");

    if (!password) return;

    password.type =
        password.type === "password"
            ? "text"
            : "password";
}


// ============================================================
// 3. ADMIN LOGIN
// ============================================================

function setupAdminLogin() {

    const form = document.getElementById("adminLoginForm");

    if (!form) return;

    form.addEventListener("submit", async function (event) {

        event.preventDefault();

        const usernameElement =
            document.getElementById("adminUsername");

        const passwordElement =
            document.getElementById("adminPassword");

        if (!usernameElement || !passwordElement) return;

        const username =
            usernameElement.value.trim();

        const password =
            passwordElement.value;

        if (!username || !password) {
            alert("Please enter username and password.");
            return;
        }

        try {

            const response = await fetch(
                "http://127.0.0.1:8000/api/auth/admin-login",
                {
                    method: "POST",

                    headers: {
                        "Content-Type": "application/json"
                    },

                    body: JSON.stringify({
                        username: username,
                        password: password
                    })
                }
            );

            const data = await response.json();

            if (!response.ok) {

                alert(
                    data.detail ||
                    "Invalid Admin Login."
                );

                return;
            }

            // Store JWT token
            localStorage.setItem(
                "accessToken",
                data.access_token
            );

            // Store login information
            localStorage.setItem(
                "adminLoggedIn",
                "true"
            );

            localStorage.setItem(
                "userRole",
                "admin"
            );

            // Open Admin Dashboard
            window.location.href = "admin.html";

        } catch (error) {

            
            console.error(
                "Admin login error:",
                error
            );

            alert(
                "Unable to connect to the backend. " +
                "Please make sure FastAPI is running."
            );
        }
    });
}


// ============================================================
// 4. STAFF LOGIN
// ============================================================

function setupStaffLogin() {

    const form =
        document.getElementById("staffLoginForm");

    if (!form) return;

    form.addEventListener("submit", function (event) {

        event.preventDefault();

        const idElement =
            document.getElementById("staffId");

        const passwordElement =
            document.getElementById("staffPassword");

        if (!idElement || !passwordElement) return;

        const staffId =
            idElement.value.trim();

        const password =
            passwordElement.value;

        if (
            staffId === "STAFF001" &&
            password === "staff123"
        ) {

            localStorage.setItem(
                "staffLoggedIn",
                "true"
            );

            localStorage.setItem(
                "userRole",
                "staff"
            );

            localStorage.setItem(
                "currentStaffId",
                staffId
            );

            window.location.href =
                "staff.html";

        } else {

            alert(
                "Invalid Staff Login!\n\n" +
                "Staff ID: STAFF001\n" +
                "Password: staff123"
            );
        }
    });
}


// ============================================================
// 5. LOGOUT
// ============================================================

function logout() {

    localStorage.removeItem("adminLoggedIn");
    localStorage.removeItem("userRole");

    window.location.href = "index.html";
}

function logoutStaff() {

    localStorage.removeItem("staffLoggedIn");
    localStorage.removeItem("userRole");
    localStorage.removeItem("currentStaffId");

    window.location.href = "index.html";
}


// ============================================================
// 6. STORAGE KEYS
// ============================================================

const STORAGE = {

    products: "warehouse_products",

    warehouses: "warehouse_warehouses",

    staff: "warehouse_staff",

    suppliers: "warehouse_suppliers",

    transactions: "warehouse_transactions",

    orders: "warehouse_orders",

    settings: "warehouse_settings"
};


// ============================================================
// 7. DEFAULT DATA
// ============================================================

const DEFAULT_DATA = {

    products: [

        {
            id: "P001",
            name: "Laptop",
            category: "Electronics",
            warehouse: "Hyderabad Warehouse",
            quantity: 50,
            price: 50000,
            supplier: "ABC Suppliers"
        },

        {
            id: "P002",
            name: "Keyboard",
            category: "Accessories",
            warehouse: "Hyderabad Warehouse",
            quantity: 25,
            price: 1200,
            supplier: "Tech Supplies"
        },

        {
            id: "P003",
            name: "Wireless Mouse",
            category: "Accessories",
            warehouse: "Secunderabad Warehouse",
            quantity: 5,
            price: 800,
            supplier: "Tech Supplies"
        },

        {
            id: "P004",
            name: "USB Cable",
            category: "Accessories",
            warehouse: "Hyderabad Warehouse",
            quantity: 8,
            price: 300,
            supplier: "ABC Suppliers"
        },

        {
            id: "P005",
            name: "HDMI Cable",
            category: "Accessories",
            warehouse: "Secunderabad Warehouse",
            quantity: 3,
            price: 500,
            supplier: "Tech Supplies"
        }

    ],

    warehouses: [

        {
            id: "W001",
            name: "Hyderabad Warehouse",
            location: "Hyderabad",
            capacity: 5000,
            manager: "Admin"
        },

        {
            id: "W002",
            name: "Secunderabad Warehouse",
            location: "Secunderabad",
            capacity: 3000,
            manager: "Admin"
        }

    ],

    staff: [

        {
            id: "STAFF001",
            name: "Staff Member",
            phone: "9876543210",
            email: "staff@example.com",
            warehouse: "Hyderabad Warehouse",
            status: "Active"
        },

        {
            id: "STAFF002",
            name: "Warehouse Assistant",
            phone: "9876500000",
            email: "assistant@example.com",
            warehouse: "Secunderabad Warehouse",
            status: "Active"
        }

    ],

    suppliers: [

        {
            id: "SUP001",
            name: "ABC Suppliers",
            contact: "9876000000",
            email: "abc@example.com",
            address: "Hyderabad"
        },

        {
            id: "SUP002",
            name: "Tech Supplies",
            contact: "9876111111",
            email: "tech@example.com",
            address: "Secunderabad"
        }

    ],

    transactions: [],

    orders: [

        {
            id: "ORD001",
            product: "Laptop",
            quantity: 2,
            customer: "Customer A",
            status: "Pending",
            date: "10-09-2026"
        },

        {
            id: "ORD002",
            product: "Keyboard",
            quantity: 5,
            customer: "Customer B",
            status: "Processing",
            date: "10-09-2026"
        }

    ],

    settings: {

        lowStock: 10,

        systemName:
            "Inventory & Warehouse Management System"

    }
};


// ============================================================
// 8. STORAGE FUNCTIONS
// ============================================================

function readData(name) {

    if (!STORAGE[name]) {
        return [];
    }

    const saved =
        localStorage.getItem(STORAGE[name]);

    if (saved) {

        try {

            const data =
                JSON.parse(saved);

            if (Array.isArray(data)) {
                return data;
            }

            if (
                typeof data === "object" &&
                data !== null
            ) {
                return data;
            }

        } catch (error) {

            console.warn(
                "Invalid stored data:",
                error
            );
        }
    }

    const original =
        DEFAULT_DATA[name];

    const copy =
        JSON.parse(
            JSON.stringify(original)
        );

    saveData(name, copy);

    return copy;
}


function saveData(name, data) {

    if (!STORAGE[name]) return;

    localStorage.setItem(
        STORAGE[name],
        JSON.stringify(data)
    );
}


function getProducts() {
    return readData("products");
}

function getWarehouses() {
    return readData("warehouses");
}

function getStaff() {
    return readData("staff");
}

function getSuppliers() {
    return readData("suppliers");
}

function getTransactions() {
    return readData("transactions");
}

function getOrders() {
    return readData("orders");
}

function getSettings() {
    return readData("settings");
}


// ============================================================
// 9. HELPER FUNCTIONS
// ============================================================

function today() {

    const date = new Date();

    return (
        String(date.getDate()).padStart(2, "0") +
        "-" +
        String(date.getMonth() + 1).padStart(2, "0") +
        "-" +
        date.getFullYear()
    );
}


function generateId(prefix, items) {

    let number = items.length + 1;

    let id =
        prefix +
        String(number).padStart(3, "0");

    while (
        items.some(function (item) {
            return item.id === id;
        })
    ) {

        number++;

        id =
            prefix +
            String(number).padStart(3, "0");
    }

    return id;
}


function money(value) {

    return (
        "₹" +
        Number(value || 0)
            .toLocaleString("en-IN")
    );
}


function escapeHTML(value) {

    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}


// ============================================================
// 10. ADMIN NAVIGATION
// ============================================================

function setupAdminNavigation() {

    const links =
        document.querySelectorAll(
            ".sidebar nav a"
        );

    if (!links.length) return;

    links.forEach(function (link) {

        link.addEventListener(
            "click",
            function (event) {

                event.preventDefault();

                links.forEach(function (item) {
                    item.classList.remove("active");
                });

                link.classList.add("active");

                const text =
                    link.textContent
                        .trim()
                        .toLowerCase();

                if (text.includes("dashboard")) {

                    showAdminDashboard();

                } else if (
                    text.includes("products")
                ) {

                    showProductsPage();

                } else if (
                    text.includes("warehouses")
                ) {

                    showWarehousesPage();

                } else if (
                    text.includes("staff")
                ) {

                    showStaffPage();

                } else if (
                    text.includes("suppliers")
                ) {

                    showSuppliersPage();

                } else if (
                    text.includes("stock in")
                ) {

                    showStockInPage();

                } else if (
                    text.includes("stock out")
                ) {

                    showStockOutPage();

                } else if (
                    text.includes("stock transfer")
                ) {

                    showStockTransferPage();

                } else if (
                    text.includes("reports")
                ) {

                    showReportsPage();

                } else if (
                    text.includes("settings")
                ) {

                    showSettingsPage();
                }
            }
        );
    });
}


// ============================================================
// 11. ADMIN CONTENT AREA
// ============================================================

function getAdminContentArea() {

    const main =
        document.querySelector(
            ".main-content"
        );

    if (!main) return null;

    let content =
        document.getElementById(
            "warehouseAppContent"
        );

    if (!content) {

        content =
            document.createElement("div");

        content.id =
            "warehouseAppContent";

        const topbar =
            main.querySelector(".topbar");

        if (topbar) {

            topbar.insertAdjacentElement(
                "afterend",
                content
            );

        } else {

            main.appendChild(content);
        }
    }

    return content;
}


function hideOriginalAdminContent() {

    const main =
        document.querySelector(
            ".main-content"
        );

    if (!main) return;

    const sections =
        main.querySelectorAll(
            ".cards, .dashboard-grid"
        );

    sections.forEach(function (section) {

        if (
            !section.closest(
                "#warehouseAppContent"
            )
        ) {

            section.style.display =
                "none";
        }
    });
}


// ============================================================
// 12. ADMIN DASHBOARD
// ============================================================

function showAdminDashboard() {

    const content =
        getAdminContentArea();

    if (!content) return;

    hideOriginalAdminContent();

    content.innerHTML = `

        <section class="cards">

            <div class="card">

                <div class="card-icon">
                    📦
                </div>

                <div>
                    <h3 id="adminTotalProducts">
                        0
                    </h3>

                    <p>Total Products</p>
                </div>

            </div>


            <div class="card">

                <div class="card-icon">
                    🏭
                </div>

                <div>
                    <h3 id="adminTotalWarehouses">
                        0
                    </h3>

                    <p>Warehouses</p>
                </div>

            </div>


            <div class="card">

                <div class="card-icon">
                    👥
                </div>

                <div>
                    <h3 id="adminTotalStaff">
                        0
                    </h3>

                    <p>Staff Members</p>
                </div>

            </div>


            <div class="card">

                <div class="card-icon">
                    ⚠️
                </div>

                <div>
                    <h3 id="adminLowStock">
                        0
                    </h3>

                    <p>Low Stock Items</p>
                </div>

            </div>

        </section>


        <section class="dashboard-grid">

            <div class="panel">

                <h2>
                    Recent Stock Activity
                </h2>

                <div style="overflow-x:auto;">

                    <table>

                        <thead>

                            <tr>
                                <th>Product</th>
                                <th>Type</th>
                                <th>Quantity</th>
                                <th>Date</th>
                            </tr>

                        </thead>

                        <tbody id="adminActivityTable">
                        </tbody>

                    </table>

                </div>

            </div>


            <div class="panel">

                <h2>
                    Low Stock
                </h2>

                <div
                    class="low-stock"
                    id="adminLowStockList">
                </div>

            </div>

        </section>
    `;

    updateAdminDashboard();
}

async function updateAdminDashboard() {

    const token =
        localStorage.getItem("accessToken");

    if (!token) {
        window.location.href = "adminlogin.html";
        return;
    }

    try {

        const [
            productsResponse,
            warehousesResponse,
            staffResponse,
            transactionsResponse
        ] = await Promise.all([

            fetch(
                "http://127.0.0.1:8000/api/products",
                {
                    headers: {
                        "Authorization":
                            `Bearer ${token}`
                    }
                }
            ),

            fetch(
                "http://127.0.0.1:8000/api/warehouses",
                {
                    headers: {
                        "Authorization":
                            `Bearer ${token}`
                    }
                }
            ),

            fetch(
                "http://127.0.0.1:8000/api/staff",
                {
                    headers: {
                        "Authorization":
                            `Bearer ${token}`
                    }
                }
            ),

            fetch(
                "http://127.0.0.1:8000/api/stock",
                {
                    headers: {
                        "Authorization":
                            `Bearer ${token}`
                    }
                }
            )

        ]);


        if (
            productsResponse.status === 401 ||
            warehousesResponse.status === 401 ||
            staffResponse.status === 401 ||
            transactionsResponse.status === 401
        ) {

            localStorage.removeItem("accessToken");
            localStorage.removeItem("adminLoggedIn");
            localStorage.removeItem("userRole");

            window.location.href =
                "adminlogin.html";

            return;
        }


        if (
            !productsResponse.ok ||
            !warehousesResponse.ok ||
            !staffResponse.ok ||
            !transactionsResponse.ok
        ) {

            throw new Error(
                "Unable to load dashboard data."
            );
        }


        const productsData =
            await productsResponse.json();

        const warehousesData =
            await warehousesResponse.json();

        const staffData =
            await staffResponse.json();

        const transactionsData =
            await transactionsResponse.json();


        const products =
            productsData.products || [];

        const warehouses =
            warehousesData.warehouses || [];

        const staff =
            staffData.staff || [];

        const transactions =
            transactionsData.transactions || [];


        // ============================
        // Dashboard counts
        // ============================

        const totalProducts =
            document.getElementById(
                "adminTotalProducts"
            );

        const totalWarehouses =
            document.getElementById(
                "adminTotalWarehouses"
            );

        const totalStaff =
            document.getElementById(
                "adminTotalStaff"
            );

        const lowStock =
            document.getElementById(
                "adminLowStock"
            );


        if (totalProducts) {
            totalProducts.textContent =
                products.length;
        }

        if (totalWarehouses) {
            totalWarehouses.textContent =
                warehouses.length;
        }

        if (totalStaff) {
            totalStaff.textContent =
                staff.length;
        }


        // ============================
        // Low stock
        // ============================

        const lowStockProducts =
            products.filter(function (product) {

                return Number(
                    product.quantity || 0
                ) <= Number(
                    product.reorder_level || 10
                );

            });


        if (lowStock) {
            lowStock.textContent =
                lowStockProducts.length;
        }


        // ============================
        // Recent activity
        // ============================

        const activityTable =
            document.getElementById(
                "adminActivityTable"
            );


        if (activityTable) {

            const recent =
                transactions
                    .slice()
                    .reverse()
                    .slice(0, 8);


            if (!recent.length) {

                activityTable.innerHTML = `
                    <tr>
                        <td
                            colspan="4"
                            style="text-align:center;"
                        >
                            No stock activity yet.
                        </td>
                    </tr>
                `;

            } else {

                activityTable.innerHTML =
                    recent.map(function (item) {

                        return `
                            <tr>

                                <td>
                                    ${escapeHTML(
                                        item.product_name ||
                                        item.product ||
                                        "Unknown Product"
                                    )}
                                </td>

                                <td>
                                    ${escapeHTML(
                                        item.transaction_type ||
                                        item.type ||
                                        ""
                                    )}
                                </td>

                                <td>
                                    ${Number(
                                        item.quantity || 0
                                    )}
                                </td>

                                <td>
                                    ${escapeHTML(
                                        item.transaction_date ||
                                        item.date ||
                                        ""
                                    )}
                                </td>

                            </tr>
                        `;

                    }).join("");
            }
        }


        // ============================
        // Low stock list
        // ============================

        const lowStockList =
            document.getElementById(
                "adminLowStockList"
            );


        if (lowStockList) {

            if (!lowStockProducts.length) {

                lowStockList.innerHTML = `
                    <p>
                        ✅ No low stock products.
                    </p>
                `;

            } else {

                lowStockList.innerHTML =
                    lowStockProducts
                        .map(function (product) {

                            return `
                                <p>

                                    ⚠️
                                    ${escapeHTML(
                                        product.product_name ||
                                        product.name ||
                                        "Unknown Product"
                                    )}

                                    <strong>
                                        ${Number(
                                            product.quantity || 0
                                        )}
                                        left
                                    </strong>

                                </p>
                            `;

                        })
                        .join("");
            }
        }


    } catch (error) {

        console.error(
            "Dashboard API Error:",
            error
        );

        alert(
            "Unable to load dashboard data from the backend."
        );
    }
}


// ============================================================
// 13. PRODUCTS
// ============================================================

function showProductsPage() {

    const content =
        getAdminContentArea();

    if (!content) return;

    hideOriginalAdminContent();

    content.innerHTML = `

        <div class="product-toolbar">

            <input
                type="text"
                id="productSearch"
                placeholder="🔍 Search products..."
            >

            <button
                class="add-product-btn"
                onclick="showProductForm()"
            >
                ➕ Add Product
            </button>

        </div>


        <div id="productFormContainer">
        </div>


        <div class="panel">

            <h2>
                Product List
            </h2>

            <div style="overflow-x:auto;">

                <table>

                    <thead>

                        <tr>
                            <th>ID</th>
                            <th>Product</th>
                            <th>Category</th>
                            <th>Warehouse</th>
                            <th>Quantity</th>
                            <th>Price</th>
                            <th>Supplier</th>
                            <th>Actions</th>
                        </tr>

                    </thead>

                    <tbody
                        id="productsTableBody">
                    </tbody>

                </table>

            </div>

        </div>
    `;


    const search =
        document.getElementById(
            "productSearch"
        );

    if (search) {

        search.addEventListener(
            "input",
            function () {

                renderProducts(
                    search.value
                );
            }
        );
    }

    renderProducts();
}


async function renderProducts(searchText = "") {

    const token =
        localStorage.getItem("accessToken");

    if (!token) {
        window.location.href = "adminlogin.html";
        return;
    }

    const tbody =
        document.getElementById(
            "productsTableBody"
        );

    if (!tbody) return;

    try {

        // Get products from FastAPI
        const productsResponse =
            await fetch(
                "http://127.0.0.1:8000/api/products",
                {
                    headers: {
                        "Authorization":
                            `Bearer ${token}`
                    }
                }
            );


        if (productsResponse.status === 401) {

            localStorage.removeItem(
                "accessToken"
            );

            localStorage.removeItem(
                "adminLoggedIn"
            );

            localStorage.removeItem(
                "userRole"
            );

            window.location.href =
                "adminlogin.html";

            return;
        }


        if (!productsResponse.ok) {

            throw new Error(
                "Unable to load products."
            );

        }


        const productsData =
            await productsResponse.json();


        // API returns:
        // { count: 100, products: [...] }

        const products =
            productsData.products || [];


        // Search
        const search =
            String(searchText)
                .toLowerCase()
                .trim();


        const filtered =
            products.filter(function (product) {

                return (

                    String(
                        product.product_code || ""
                    )
                        .toLowerCase()
                        .includes(search)

                    ||

                    String(
                        product.product_name || ""
                    )
                        .toLowerCase()
                        .includes(search)

                    ||

                    String(
                        product.category || ""
                    )
                        .toLowerCase()
                        .includes(search)

                    ||

                    String(
                        product.warehouse_id || ""
                    )
                        .toLowerCase()
                        .includes(search)

                    ||

                    String(
                        product.supplier_id || ""
                    )
                        .toLowerCase()
                        .includes(search)

                );

            });


        // No products
        if (!filtered.length) {

            tbody.innerHTML = `

                <tr>

                    <td
                        colspan="8"
                        style="text-align:center;"
                    >
                        No products found.
                    </td>

                </tr>

            `;

            return;
        }


        // Display products
        tbody.innerHTML =
            filtered.map(function (product) {

                return `

                    <tr>

                        <td>
                            ${escapeHTML(
                                product.product_code ||
                                product.product_id ||
                                ""
                            )}
                        </td>

                        <td>
                            ${escapeHTML(
                                product.product_name ||
                                ""
                            )}
                        </td>

                        <td>
                            ${escapeHTML(
                                product.category ||
                                ""
                            )}
                        </td>

                        <td>
                            ${escapeHTML(
                                product.warehouse_id ||
                                ""
                            )}
                        </td>

                        <td>
                            ${Number(
                                product.quantity || 0
                            )}
                        </td>

                        <td>
                            ${money(
                                product.price || 0
                            )}
                        </td>

                        <td>
                            ${escapeHTML(
                                product.supplier_id ||
                                ""
                            )}
                        </td>

                        <td>

                            <button
                                class="edit-btn"
                                onclick="editProduct(${product.product_id})"
                            >
                                Edit
                            </button>

                            <button
                                class="delete-btn"
                                onclick="deleteProduct(${product.product_id})"
                            >
                                Delete
                            </button>

                        </td>

                    </tr>

                `;

            }).join("");


    } catch (error) {

        console.error(
            "Products API Error:",
            error
        );


        tbody.innerHTML = `

            <tr>

                <td
                    colspan="8"
                    style="text-align:center;"
                >
                    Unable to load products
                    from backend.
                </td>

            </tr>

        `;

    }
}

// ============================================================
// 14. PRODUCT FORM
// ============================================================

function showProductForm(productId = null) {

    const container =
        document.getElementById(
            "productFormContainer"
        );

    if (!container) return;


    const products =
        getProducts();

    let product = null;


    if (productId) {

        product =
            products.find(function (item) {

                return item.id === productId;

            });
    }


    container.innerHTML = `

        <div class="product-form">

            <h2>
                ${
                    product
                        ? "✏️ Edit Product"
                        : "➕ Add New Product"
                }
            </h2>


            <div class="form-grid">

                <input
                    type="text"
                    id="productName"
                    placeholder="Product Name"
                    value="${
                        product
                            ? escapeHTML(product.name)
                            : ""
                    }"
                >


                <input
                    type="text"
                    id="productCategory"
                    placeholder="Category"
                    value="${
                        product
                            ? escapeHTML(product.category)
                            : ""
                    }"
                >


                <input
                    type="text"
                    id="productWarehouse"
                    placeholder="Warehouse"
                    value="${
                        product
                            ? escapeHTML(product.warehouse)
                            : ""
                    }"
                >


                <input
                    type="number"
                    id="productQuantity"
                    placeholder="Quantity"
                    min="0"
                    value="${
                        product
                            ? Number(product.quantity)
                            : ""
                    }"
                >


                <input
                    type="number"
                    id="productPrice"
                    placeholder="Price"
                    min="0"
                    value="${
                        product
                            ? Number(product.price)
                            : ""
                    }"
                >


                <input
                    type="text"
                    id="productSupplier"
                    placeholder="Supplier"
                    value="${
                        product
                            ? escapeHTML(product.supplier)
                            : ""
                    }"
                >

            </div>


            <div class="form-buttons">

                <button
                    class="save-btn"
                    onclick="${
                        product
                            ? `saveEditedProduct('${escapeHTML(product.id)}')`
                            : "addProduct()"
                    }"
                >
                    💾 Save Product
                </button>


                <button
                    class="cancel-btn"
                    onclick="cancelProductForm()"
                >
                    Cancel
                </button>

            </div>

        </div>
    `;


    container.scrollIntoView({
        behavior: "smooth",
        block: "start"
    });
}


// ============================================================
// 15. ADD PRODUCT
// ============================================================
async function addProduct() {

    const token =
        localStorage.getItem("accessToken");

    if (!token) {
        window.location.href = "adminlogin.html";
        return;
    }


    const nameElement =
        document.getElementById("productName");

    const categoryElement =
        document.getElementById("productCategory");

    const warehouseElement =
        document.getElementById("productWarehouse");

    const quantityElement =
        document.getElementById("productQuantity");

    const priceElement =
        document.getElementById("productPrice");

    const supplierElement =
        document.getElementById("productSupplier");


    if (
        !nameElement ||
        !categoryElement ||
        !warehouseElement ||
        !quantityElement ||
        !priceElement ||
        !supplierElement
    ) {
        return;
    }


    const name =
        nameElement.value.trim();

    const category =
        categoryElement.value.trim();

    const warehouse =
        warehouseElement.value.trim();

    const quantity =
        Number(quantityElement.value);

    const price =
        Number(priceElement.value);

    const supplier =
        supplierElement.value.trim();


    // Validation

    if (
        !name ||
        !category ||
        !warehouse ||
        !supplier
    ) {

        alert(
            "Please fill all product details."
        );

        return;
    }


    if (
        !Number.isFinite(quantity) ||
        quantity < 0
    ) {

        alert(
            "Quantity must be a valid number."
        );

        return;
    }


    if (
        !Number.isFinite(price) ||
        price < 0
    ) {

        alert(
            "Price must be a valid number."
        );

        return;
    }


    try {

        /*
         * The database uses warehouse_id
         * and supplier_id.
         *
         * Your existing form uses text fields,
         * so the value entered must be the
         * corresponding database ID.
         */

        const warehouseId =
            Number(warehouse);

        const supplierId =
            Number(supplier);


        if (
            !Number.isInteger(warehouseId) ||
            warehouseId <= 0
        ) {

            alert(
                "Please enter a valid Warehouse ID."
            );

            return;
        }


        if (
            !Number.isInteger(supplierId) ||
            supplierId <= 0
        ) {

            alert(
                "Please enter a valid Supplier ID."
            );

            return;
        }


        // Get existing products to generate
        // the next product code.

        const productsResponse =
            await fetch(
                "http://127.0.0.1:8000/api/products",
                {
                    headers: {
                        "Authorization":
                            `Bearer ${token}`
                    }
                }
            );


        if (!productsResponse.ok) {

            throw new Error(
                "Unable to read existing products."
            );

        }


        const productsData =
            await productsResponse.json();

        const products =
            productsData.products || [];


        // Generate product code

        let maxNumber = 0;

        products.forEach(function (product) {

            const code =
                String(
                    product.product_code || ""
                );

            const match =
                code.match(/^P(\d+)$/i);

            if (match) {

                const number =
                    Number(match[1]);

                if (number > maxNumber) {
                    maxNumber = number;
                }

            }

        });


        const productCode =
            "P" +
            String(maxNumber + 1)
                .padStart(3, "0");


        // Product data sent to FastAPI

        const productData = {

            product_code:
                productCode,

            product_name:
                name,

            category:
                category,

            warehouse_id:
                warehouseId,

            quantity:
                quantity,

            price:
                price,

            supplier_id:
                supplierId,

            reorder_level:
                10,

            status:
                "Available"
        };


        // Send product to FastAPI

        const response =
            await fetch(
                "http://127.0.0.1:8000/api/products",
                {
                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/json",

                        "Authorization":
                            `Bearer ${token}`
                    },

                    body:
                        JSON.stringify(
                            productData
                        )
                }
            );


        const data =
            await response.json();


        if (response.status === 401) {

            localStorage.removeItem(
                "accessToken"
            );

            localStorage.removeItem(
                "adminLoggedIn"
            );

            localStorage.removeItem(
                "userRole"
            );

            window.location.href =
                "adminlogin.html";

            return;
        }


        if (!response.ok) {

            console.error(
                "Product API Error:",
                data
            );

            alert(
                data.detail ||
                "Unable to add product."
            );

            return;
        }


        alert(
            "Product added successfully!"
        );


        // Return to product list

        showProductsPage();


    } catch (error) {

        console.error(
            "Add Product Error:",
            error
        );

        alert(
            "Unable to connect to the backend."
        );

    }
}


// ============================================================
// 16. EDIT PRODUCT
// ============================================================

function editProduct(id) {

    showProductForm(id);
}


// ============================================================
// 17. SAVE EDITED PRODUCT
// ============================================================

async function saveEditedProduct(id) {

    const token =
        localStorage.getItem("accessToken");

    if (!token) {
        window.location.href = "adminlogin.html";
        return;
    }


    const nameElement =
        document.getElementById("productName");

    const categoryElement =
        document.getElementById("productCategory");

    const warehouseElement =
        document.getElementById("productWarehouse");

    const quantityElement =
        document.getElementById("productQuantity");

    const priceElement =
        document.getElementById("productPrice");

    const supplierElement =
        document.getElementById("productSupplier");


    if (
        !nameElement ||
        !categoryElement ||
        !warehouseElement ||
        !quantityElement ||
        !priceElement ||
        !supplierElement
    ) {
        return;
    }


    const name =
        nameElement.value.trim();

    const category =
        categoryElement.value.trim();

    const warehouseId =
        Number(
            warehouseElement.value.trim()
        );

    const quantity =
        Number(quantityElement.value);

    const price =
        Number(priceElement.value);

    const supplierId =
        Number(
            supplierElement.value.trim()
        );


    // Validation

    if (
        !name ||
        !category
    ) {

        alert(
            "Please fill all product details."
        );

        return;
    }


    if (
        !Number.isInteger(warehouseId) ||
        warehouseId <= 0
    ) {

        alert(
            "Please enter a valid Warehouse ID."
        );

        return;
    }


    if (
        !Number.isInteger(supplierId) ||
        supplierId <= 0
    ) {

        alert(
            "Please enter a valid Supplier ID."
        );

        return;
    }


    if (
        !Number.isFinite(quantity) ||
        quantity < 0
    ) {

        alert(
            "Quantity must be a valid number."
        );

        return;
    }


    if (
        !Number.isFinite(price) ||
        price < 0
    ) {

        alert(
            "Price must be a valid number."
        );

        return;
    }


    try {

        const productData = {

            product_name:
                name,

            category:
                category,

            warehouse_id:
                warehouseId,

            quantity:
                quantity,

            price:
                price,

            supplier_id:
                supplierId
        };


        const response =
            await fetch(
                `http://127.0.0.1:8000/api/products/${id}`,
                {
                    method: "PUT",

                    headers: {
                        "Content-Type":
                            "application/json",

                        "Authorization":
                            `Bearer ${token}`
                    },

                    body:
                        JSON.stringify(
                            productData
                        )
                }
            );


        const data =
            await response.json();


        if (response.status === 401) {

            localStorage.removeItem(
                "accessToken"
            );

            localStorage.removeItem(
                "adminLoggedIn"
            );

            localStorage.removeItem(
                "userRole"
            );

            window.location.href =
                "adminlogin.html";

            return;
        }


        if (!response.ok) {

            console.error(
                "Update Product API Error:",
                data
            );

            alert(
                data.detail ||
                "Unable to update product."
            );

            return;
        }


        alert(
            "Product updated successfully!"
        );


        showProductsPage();


    } catch (error) {

        console.error(
            "Update Product Error:",
            error
        );

        alert(
            "Unable to connect to the backend."
        );

    }
}
// ============================================================
// 18. DELETE PRODUCT
// ============================================================
async function deleteProduct(id) {

    const token =
        localStorage.getItem("accessToken");

    if (!token) {
        window.location.href = "adminlogin.html";
        return;
    }


    // Get product name before deleting
    let productName = "this product";

    try {

        const productResponse =
            await fetch(
                `http://127.0.0.1:8000/api/products/${id}`,
                {
                    headers: {
                        "Authorization":
                            `Bearer ${token}`
                    }
                }
            );


        if (productResponse.status === 401) {

            localStorage.removeItem(
                "accessToken"
            );

            localStorage.removeItem(
                "adminLoggedIn"
            );

            localStorage.removeItem(
                "userRole"
            );

            window.location.href =
                "adminlogin.html";

            return;
        }


        if (productResponse.ok) {

            const product =
                await productResponse.json();

            productName =
                product.product_name ||
                product.name ||
                "this product";
        }


    } catch (error) {

        console.error(
            "Product lookup error:",
            error
        );

    }


    // Confirmation

    const confirmed =
        confirm(
            "Are you sure you want to delete " +
            productName +
            "?"
        );


    if (!confirmed) {
        return;
    }


    try {

        const response =
            await fetch(
                `http://127.0.0.1:8000/api/products/${id}`,
                {
                    method: "DELETE",

                    headers: {
                        "Authorization":
                            `Bearer ${token}`
                    }
                }
            );


        const data =
            await response.json();


        if (response.status === 401) {

            localStorage.removeItem(
                "accessToken"
            );

            localStorage.removeItem(
                "adminLoggedIn"
            );

            localStorage.removeItem(
                "userRole"
            );

            window.location.href =
                "adminlogin.html";

            return;
        }


        if (!response.ok) {

            console.error(
                "Delete Product API Error:",
                data
            );

            alert(
                data.detail ||
                "Unable to delete product."
            );

            return;
        }


        alert(
            "Product deleted successfully!"
        );


        // Reload product list from MySQL

        showProductsPage();


    } catch (error) {

        console.error(
            "Delete Product Error:",
            error
        );

        alert(
            "Unable to connect to the backend."
        );

    }
}

// ============================================================
// 19. CANCEL PRODUCT FORM
// ============================================================

function cancelProductForm() {

    const container =
        document.getElementById(
            "productFormContainer"
        );

    if (container) {

        container.innerHTML = "";
    }
}


// ============================================================
// 20. GENERIC MODULE PAGE
// ============================================================

function showModulePage(title, message) {

    const content =
        getAdminContentArea();

    if (!content) return;

    hideOriginalAdminContent();

    content.innerHTML = `

        <div class="panel">

            <h2>
                ${escapeHTML(title)}
            </h2>

            <p>
                ${escapeHTML(message)}
            </p>

        </div>
    `;
}


// ============================================================
// 21. WAREHOUSES
// ============================================================
// ============================================================
// 21. WAREHOUSES
// ============================================================

function showWarehousesPage() {

    const content = getAdminContentArea();

    if (!content) return;

    hideOriginalAdminContent();

    content.innerHTML = `

        <div class="product-toolbar">

            <input
                type="text"
                id="warehouseSearch"
                placeholder="🔍 Search warehouses..."
            >

            <button
                class="add-product-btn"
                onclick="showWarehouseForm()"
            >
                ➕ Add Warehouse
            </button>

        </div>

        <div id="warehouseFormContainer"></div>

        <div id="warehouseDetailsContainer"></div>

        <div class="panel">

            <h2>🏭 Warehouses</h2>

            <p style="margin-bottom:20px;color:#666;">
                Select a warehouse to view its capacity,
                stored products and current stock.
            </p>

            <div
                id="warehouseCardsContainer"
                class="warehouse-cards-container"
            >
            </div>

        </div>
    `;

    const search =
        document.getElementById("warehouseSearch");

    if (search) {

        search.addEventListener(
            "input",
            function () {

                loadWarehouses(search.value);

            }
        );

    }

    loadWarehouses();
}


// ============================================================
// LOAD WAREHOUSE CARDS
// ============================================================

async function loadWarehouses(searchTerm = "") {

    const token =
        localStorage.getItem("accessToken");

    if (!token) {

        window.location.href =
            "adminlogin.html";

        return;
    }

    try {

        // -----------------------------
        // GET WAREHOUSES
        // -----------------------------

        const warehouseResponse =
            await fetch(
                "http://127.0.0.1:8000/api/warehouses",
                {
                    method: "GET",

                    headers: {
                        "Authorization":
                            `Bearer ${token}`
                    }
                }
            );

        const warehouseData =
            await warehouseResponse.json();


        // -----------------------------
        // AUTH CHECK
        // -----------------------------

        if (warehouseResponse.status === 401) {

            localStorage.removeItem("accessToken");
            localStorage.removeItem("adminLoggedIn");
            localStorage.removeItem("userRole");

            window.location.href =
                "adminlogin.html";

            return;
        }


        if (!warehouseResponse.ok) {

            alert(
                warehouseData.detail ||
                "Unable to load warehouses."
            );

            return;
        }


        const warehouses =
            warehouseData.warehouses || [];


        // -----------------------------
        // GET PRODUCTS
        // -----------------------------

        const productResponse =
            await fetch(
                "http://127.0.0.1:8000/api/products",
                {
                    method: "GET",

                    headers: {
                        "Authorization":
                            `Bearer ${token}`
                    }
                }
            );


        const productData =
            await productResponse.json();


        if (productResponse.status === 401) {

            localStorage.removeItem("accessToken");
            localStorage.removeItem("adminLoggedIn");
            localStorage.removeItem("userRole");

            window.location.href =
                "adminlogin.html";

            return;
        }


        if (!productResponse.ok) {

            alert(
                productData.detail ||
                "Unable to load products."
            );

            return;
        }


        const products =
            productData.products || [];


        // -----------------------------
        // SEARCH
        // -----------------------------

        const filteredWarehouses =
            warehouses.filter(function (warehouse) {

                const text = `

                    ${warehouse.warehouse_code || ""}

                    ${warehouse.warehouse_name || ""}

                    ${warehouse.location || ""}

                    ${warehouse.status || ""}

                `.toLowerCase();


                return text.includes(
                    searchTerm.toLowerCase()
                );

            });


        const container =
            document.getElementById(
                "warehouseCardsContainer"
            );


        if (!container) return;


        // -----------------------------
        // NO RESULTS
        // -----------------------------

        if (filteredWarehouses.length === 0) {

            container.innerHTML = `

                <div style="
                    padding:40px;
                    text-align:center;
                    color:#777;
                    width:100%;
                ">

                    <h3>🏭 No warehouses found</h3>

                    <p>
                        Try another search or add a new warehouse.
                    </p>

                </div>

            `;

            return;
        }


        // -----------------------------
        // CREATE CARDS
        // -----------------------------

        container.innerHTML =

            filteredWarehouses.map(
                function (warehouse) {


                    // Products belonging to this warehouse

                    const warehouseProducts =
                        products.filter(
                            function (product) {

                                return Number(
                                    product.warehouse_id
                                ) === Number(
                                    warehouse.warehouse_id
                                );

                            }
                        );


                    // Total quantity stored

                    const currentStock =
                        warehouseProducts.reduce(
                            function (total, product) {

                                return total +
                                    Number(
                                        product.quantity || 0
                                    );

                            },
                            0
                        );


                    // Capacity

                    const capacity =
                        Number(
                            warehouse.capacity || 0
                        );


                    // Available space

                    const availableSpace =
                        Math.max(
                            capacity - currentStock,
                            0
                        );


                    // Utilization percentage

                    const utilization =
                        capacity > 0
                            ? Math.min(
                                (currentStock / capacity) * 100,
                                100
                            )
                            : 0;


                    return `

                        <div
                            class="warehouse-card"
                            onclick="
                                showWarehouseDetails(
                                    ${warehouse.warehouse_id}
                                )
                            "
                            style="
                                cursor:pointer;
                                background:white;
                                border-radius:14px;
                                padding:22px;
                                box-shadow:0 4px 15px rgba(0,0,0,0.10);
                                border:1px solid #e5e7eb;
                                transition:0.2s;
                            "
                            onmouseover="
                                this.style.transform='translateY(-4px)';
                                this.style.boxShadow='0 8px 22px rgba(0,0,0,0.15)';
                            "
                            onmouseout="
                                this.style.transform='translateY(0)';
                                this.style.boxShadow='0 4px 15px rgba(0,0,0,0.10)';
                            "
                        >

                            <div style="
                                display:flex;
                                justify-content:space-between;
                                align-items:center;
                                margin-bottom:15px;
                            ">

                                <div>

                                    <h2 style="
                                        margin:0;
                                        font-size:20px;
                                    ">

                                        🏭
                                        ${escapeHTML(
                                            warehouse.warehouse_name || ""
                                        )}

                                    </h2>

                                    <p style="
                                        margin:5px 0 0;
                                        color:#777;
                                    ">

                                        ${escapeHTML(
                                            warehouse.warehouse_code || ""
                                        )}

                                    </p>

                                </div>


                                <span style="
                                    padding:5px 10px;
                                    border-radius:20px;
                                    background:#e8f5e9;
                                    color:#2e7d32;
                                    font-size:12px;
                                    font-weight:bold;
                                ">

                                    ${escapeHTML(
                                        warehouse.status || "Active"
                                    )}

                                </span>

                            </div>


                            <p style="
                                margin:8px 0;
                                color:#555;
                            ">

                                📍
                                ${escapeHTML(
                                    warehouse.location || "Not specified"
                                )}

                            </p>


                            <hr style="
                                border:none;
                                border-top:1px solid #eee;
                                margin:15px 0;
                            ">


                            <div style="
                                display:grid;
                                grid-template-columns:repeat(2,1fr);
                                gap:12px;
                            ">

                                <div>

                                    <small style="color:#777;">
                                        Capacity
                                    </small>

                                    <h3 style="margin:4px 0;">

                                        ${capacity}

                                    </h3>

                                </div>


                                <div>

                                    <small style="color:#777;">
                                        Current Stock
                                    </small>

                                    <h3 style="margin:4px 0;">

                                        ${currentStock}

                                    </h3>

                                </div>


                                <div>

                                    <small style="color:#777;">
                                        Available Space
                                    </small>

                                    <h3 style="
                                        margin:4px 0;
                                        color:#2e7d32;
                                    ">

                                        ${availableSpace}

                                    </h3>

                                </div>


                                <div>

                                    <small style="color:#777;">
                                        Products
                                    </small>

                                    <h3 style="margin:4px 0;">

                                        ${warehouseProducts.length}

                                    </h3>

                                </div>

                            </div>


                            <div style="margin-top:15px;">

                                <div style="
                                    display:flex;
                                    justify-content:space-between;
                                    font-size:13px;
                                    margin-bottom:5px;
                                ">

                                    <span>
                                        Storage Used
                                    </span>

                                    <strong>
                                        ${utilization.toFixed(1)}%
                                    </strong>

                                </div>


                                <div style="
                                    width:100%;
                                    height:8px;
                                    background:#e5e7eb;
                                    border-radius:10px;
                                    overflow:hidden;
                                ">

                                    <div style="
                                        width:${utilization}%;
                                        height:100%;
                                        background:#1976d2;
                                        border-radius:10px;
                                    ">
                                    </div>

                                </div>

                            </div>


                            <div style="
                                margin-top:18px;
                                display:flex;
                                gap:8px;
                            ">

                                <button
                                    onclick="
                                        event.stopPropagation();
                                        editWarehouse(
                                            ${warehouse.warehouse_id}
                                        );
                                    "
                                >
                                    ✏️ Edit
                                </button>


                                <button
                                    onclick="
                                        event.stopPropagation();
                                        deleteWarehouse(
                                            ${warehouse.warehouse_id}
                                        );
                                    "
                                >
                                    🗑️ Delete
                                </button>

                            </div>


                            <p style="
                                margin:15px 0 0;
                                text-align:center;
                                color:#1976d2;
                                font-size:13px;
                            ">

                                👆 Click to view warehouse details

                            </p>

                        </div>

                    `;

                }
            ).join("");

    }

    catch (error) {

        console.error(
            "Load Warehouses Error:",
            error
        );

        alert(
            "Unable to connect to the backend. " +
            "Please make sure FastAPI is running."
        );

    }
}
// ============================================================
// WAREHOUSE DETAILS
// ============================================================

async function showWarehouseDetails(warehouseId) {

    const token =
        localStorage.getItem("accessToken");

    if (!token) {

        window.location.href =
            "adminlogin.html";

        return;
    }

    try {

        // -----------------------------
        // GET WAREHOUSE
        // -----------------------------

        const warehouseResponse =
            await fetch(
                `http://127.0.0.1:8000/api/warehouses/${warehouseId}`,
                {
                    method: "GET",

                    headers: {
                        "Authorization":
                            `Bearer ${token}`
                    }
                }
            );


        const warehouseData =
            await warehouseResponse.json();


        if (warehouseResponse.status === 401) {

            localStorage.removeItem("accessToken");
            localStorage.removeItem("adminLoggedIn");
            localStorage.removeItem("userRole");

            window.location.href =
                "adminlogin.html";

            return;
        }


        if (!warehouseResponse.ok) {

            alert(
                warehouseData.detail ||
                "Unable to load warehouse."
            );

            return;
        }


        const warehouse =
            warehouseData.warehouse;


        // -----------------------------
        // GET PRODUCTS
        // -----------------------------

        const productResponse =
            await fetch(
                "http://127.0.0.1:8000/api/products",
                {
                    method: "GET",

                    headers: {
                        "Authorization":
                            `Bearer ${token}`
                    }
                }
            );


        const productData =
            await productResponse.json();


        if (!productResponse.ok) {

            alert(
                productData.detail ||
                "Unable to load products."
            );

            return;
        }


        const products =
            productData.products || [];


        // -----------------------------
        // PRODUCTS IN THIS WAREHOUSE
        // -----------------------------

        const warehouseProducts =
            products.filter(
                function (product) {

                    return Number(
                        product.warehouse_id
                    ) === Number(
                        warehouseId
                    );

                }
            );


        // -----------------------------
        // CAPACITY CALCULATIONS
        // -----------------------------

        const capacity =
            Number(
                warehouse.capacity || 0
            );


        const currentStock =
            warehouseProducts.reduce(
                function (total, product) {

                    return total +
                        Number(
                            product.quantity || 0
                        );

                },
                0
            );


        const availableSpace =
            Math.max(
                capacity - currentStock,
                0
            );


        const utilization =
            capacity > 0
                ? Math.min(
                    (currentStock / capacity) * 100,
                    100
                )
                : 0;


        // -----------------------------
        // DETAILS CONTAINER
        // -----------------------------

        const detailsContainer =
            document.getElementById(
                "warehouseDetailsContainer"
            );


        if (!detailsContainer) return;


        // -----------------------------
        // PRODUCT TABLE
        // -----------------------------

        let productTable = "";


        if (warehouseProducts.length === 0) {

            productTable = `

                <tr>

                    <td
                        colspan="6"
                        style="
                            text-align:center;
                            padding:30px;
                            color:#777;
                        "
                    >

                        📦 No products are currently
                        stored in this warehouse.

                    </td>

                </tr>

            `;

        } else {

            productTable =
                warehouseProducts.map(
                    function (product) {

                        return `

                            <tr>

                                <td>

                                    ${escapeHTML(
                                        product.product_code || ""
                                    )}

                                </td>


                                <td>

                                    ${escapeHTML(
                                        product.product_name || ""
                                    )}

                                </td>


                                <td>

                                    ${escapeHTML(
                                        product.category || ""
                                    )}

                                </td>


                                <td>

                                    <strong>
                                        ${product.quantity ?? 0}
                                    </strong>

                                </td>


                                <td>

                                    ₹${Number(
                                        product.price || 0
                                    ).toLocaleString("en-IN")}

                                </td>


                                <td>

                                    ${escapeHTML(
                                        product.status || ""
                                    )}

                                </td>

                            </tr>

                        `;

                    }
                ).join("");

        }


        // -----------------------------
        // DISPLAY DETAILS
        // -----------------------------

        detailsContainer.innerHTML = `

            <div
                class="panel"
                style="
                    margin-bottom:25px;
                    border-left:5px solid #1976d2;
                "
            >

                <div style="
                    display:flex;
                    justify-content:space-between;
                    align-items:center;
                    flex-wrap:wrap;
                    gap:10px;
                ">

                    <div>

                        <h2 style="margin:0;">

                            🏭
                            ${escapeHTML(
                                warehouse.warehouse_name || ""
                            )}

                        </h2>

                        <p style="
                            margin:5px 0;
                            color:#777;
                        ">

                            ${escapeHTML(
                                warehouse.warehouse_code || ""
                            )}

                        </p>

                    </div>


                    <button
                        onclick="
                            document.getElementById(
                                'warehouseDetailsContainer'
                            ).innerHTML='';
                        "
                    >
                        ✖ Close
                    </button>

                </div>


                <hr style="
                    border:none;
                    border-top:1px solid #eee;
                    margin:20px 0;
                ">


                <!-- BASIC INFORMATION -->

                <h3>
                    📋 Warehouse Information
                </h3>


                <div style="
                    display:grid;
                    grid-template-columns:
                        repeat(auto-fit,minmax(180px,1fr));
                    gap:15px;
                    margin-top:15px;
                ">


                    <div style="
                        background:#f8fafc;
                        padding:15px;
                        border-radius:10px;
                    ">

                        <small>
                            Warehouse Code
                        </small>

                        <h3 style="margin:5px 0;">

                            ${escapeHTML(
                                warehouse.warehouse_code || ""
                            )}

                        </h3>

                    </div>


                    <div style="
                        background:#f8fafc;
                        padding:15px;
                        border-radius:10px;
                    ">

                        <small>
                            Location
                        </small>

                        <h3 style="margin:5px 0;">

                            ${escapeHTML(
                                warehouse.location || ""
                            )}

                        </h3>

                    </div>


                    <div style="
                        background:#f8fafc;
                        padding:15px;
                        border-radius:10px;
                    ">

                        <small>
                            Total Capacity
                        </small>

                        <h3 style="margin:5px 0;">

                            ${capacity}

                        </h3>

                    </div>


                    <div style="
                        background:#f8fafc;
                        padding:15px;
                        border-radius:10px;
                    ">

                        <small>
                            Current Stock
                        </small>

                        <h3 style="margin:5px 0;">

                            ${currentStock}

                        </h3>

                    </div>


                    <div style="
                        background:#f8fafc;
                        padding:15px;
                        border-radius:10px;
                    ">

                        <small>
                            Available Space
                        </small>

                        <h3 style="
                            margin:5px 0;
                            color:#2e7d32;
                        ">

                            ${availableSpace}

                        </h3>

                    </div>


                    <div style="
                        background:#f8fafc;
                        padding:15px;
                        border-radius:10px;
                    ">

                        <small>
                            Status
                        </small>

                        <h3 style="margin:5px 0;">

                            ${escapeHTML(
                                warehouse.status || ""
                            )}

                        </h3>

                    </div>

                </div>


                <!-- CAPACITY -->

                <div style="margin-top:25px;">

                    <div style="
                        display:flex;
                        justify-content:space-between;
                        margin-bottom:7px;
                    ">

                        <strong>
                            Warehouse Capacity Usage
                        </strong>

                        <strong>
                            ${utilization.toFixed(1)}%
                        </strong>

                    </div>


                    <div style="
                        width:100%;
                        height:14px;
                        background:#e5e7eb;
                        border-radius:20px;
                        overflow:hidden;
                    ">

                        <div style="
                            width:${utilization}%;
                            height:100%;
                            background:#1976d2;
                            border-radius:20px;
                        ">
                        </div>

                    </div>

                </div>


                <!-- PRODUCTS -->

                <div style="margin-top:30px;">

                    <h3>
                        📦 Products Stored in This Warehouse
                    </h3>


                    <div style="
                        overflow-x:auto;
                        margin-top:15px;
                    ">

                        <table>

                            <thead>

                                <tr>

                                    <th>
                                        Product Code
                                    </th>

                                    <th>
                                        Product Name
                                    </th>

                                    <th>
                                        Category
                                    </th>

                                    <th>
                                        Quantity
                                    </th>

                                    <th>
                                        Price
                                    </th>

                                    <th>
                                        Status
                                    </th>

                                </tr>

                            </thead>


                            <tbody>

                                ${productTable}

                            </tbody>

                        </table>

                    </div>

                </div>

            </div>
        `;


        // Scroll to details

        detailsContainer.scrollIntoView({
            behavior: "smooth",
            block: "start"
        });

    }

    catch (error) {

        console.error(
            "Warehouse Details Error:",
            error
        );

        alert(
            "Unable to load warehouse details."
        );

    }
}


async function deleteWarehouse(id) {

    const token = localStorage.getItem("accessToken");

    if (!token) {
        window.location.href = "adminlogin.html";
        return;
    }

    const confirmDelete = confirm(
        "Are you sure you want to delete this warehouse?"
    );

    if (!confirmDelete) {
        return;
    }

    try {

        const response = await fetch(
            `http://127.0.0.1:8000/api/warehouses/${id}`,
            {
                method: "DELETE",

                headers: {
                    "Authorization": `Bearer ${token}`
                }
            }
        );

        const data = await response.json();

        if (response.status === 401) {

            localStorage.removeItem("accessToken");
            localStorage.removeItem("adminLoggedIn");
            localStorage.removeItem("userRole");

            window.location.href = "adminlogin.html";
            return;
        }

        if (!response.ok) {

            console.error(
                "Delete Warehouse API Error:",
                data
            );

            alert(
                data.detail ||
                "Unable to delete warehouse."
            );

            return;
        }

        alert("Warehouse deleted successfully!");

        showWarehousesPage();

    } catch (error) {

        console.error(
            "Delete Warehouse Error:",
            error
        );

        alert(
            "Unable to connect to the backend."
        );
    }
}



// ============================================================
// WAREHOUSE FORM
// ============================================================

function showWarehouseForm(warehouse = null) {

    const container =
        document.getElementById("warehouseFormContainer");

    if (!container) return;

    container.innerHTML = `

        <div class="product-form">

            <h2>
                ${
                    warehouse
                        ? "✏️ Edit Warehouse"
                        : "➕ Add New Warehouse"
                }
            </h2>

            <div class="form-grid">

                <input
                    type="text"
                    id="warehouseCode"
                    placeholder="Warehouse Code"
                    value="${
                        warehouse
                            ? escapeHTML(
                                warehouse.warehouse_code || ""
                            )
                            : ""
                    }"
                >

                <input
                    type="text"
                    id="warehouseName"
                    placeholder="Warehouse Name"
                    value="${
                        warehouse
                            ? escapeHTML(
                                warehouse.warehouse_name || ""
                            )
                            : ""
                    }"
                >

                <input
                    type="text"
                    id="warehouseLocation"
                    placeholder="Location"
                    value="${
                        warehouse
                            ? escapeHTML(
                                warehouse.location || ""
                            )
                            : ""
                    }"
                >

                <input
                    type="number"
                    id="warehouseCapacity"
                    placeholder="Capacity"
                    min="0"
                    value="${
                        warehouse
                            ? Number(
                                warehouse.capacity || 0
                            )
                            : ""
                    }"
                >

            </div>

            <div class="form-buttons">

                <button
                    class="save-btn"
                    onclick="${
                        warehouse
                            ? `updateWarehouse(${warehouse.warehouse_id})`
                            : "saveWarehouse()"
                    }"
                >
                    💾 ${
                        warehouse
                            ? "Update Warehouse"
                            : "Save Warehouse"
                    }
                </button>

                <button
                    class="cancel-btn"
                    onclick="cancelWarehouseForm()"
                >
                    Cancel
                </button>

            </div>

        </div>
    `;

    container.scrollIntoView({
        behavior: "smooth",
        block: "start"
    });
}

async function editWarehouse(id) {

    const token = localStorage.getItem("accessToken");

    if (!token) {
        window.location.href = "adminlogin.html";
        return;
    }

    try {

        const response = await fetch(
            `http://127.0.0.1:8000/api/warehouses/${id}`,
            {
                method: "GET",
                headers: {
                    "Authorization": `Bearer ${token}`
                }
            }
        );

        const data = await response.json();

        if (response.status === 401) {
            localStorage.removeItem("accessToken");
            localStorage.removeItem("adminLoggedIn");
            localStorage.removeItem("userRole");
            window.location.href = "adminlogin.html";
            return;
        }

        if (!response.ok) {
            alert(data.detail || "Unable to load warehouse.");
            return;
        }

        const warehouse = data.warehouse || data;

        showWarehouseForm(warehouse);

    } catch (error) {

        console.error("Edit Warehouse Error:", error);
        alert("Unable to connect to the backend.");

    }
}


async function updateWarehouse(id) {

    const token = localStorage.getItem("accessToken");

    if (!token) {
        window.location.href = "adminlogin.html";
        return;
    }

    const code =
        document.getElementById("warehouseCode").value.trim();

    const name =
        document.getElementById("warehouseName").value.trim();

    const location =
        document.getElementById("warehouseLocation").value.trim();

    const capacity =
        Number(document.getElementById("warehouseCapacity").value);

    if (!code || !name || !location) {
        alert("Please fill all warehouse details.");
        return;
    }

    if (!Number.isFinite(capacity) || capacity < 0) {
        alert("Capacity must be a valid number.");
        return;
    }

    try {

        const response = await fetch(
            `http://127.0.0.1:8000/api/warehouses/${id}`,
            {
                method: "PUT",

                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${token}`
                },

                body: JSON.stringify({
                    warehouse_code: code,
                    warehouse_name: name,
                    location: location,
                    capacity: capacity,
                    status: "Active"
                })
            }
        );

        const data = await response.json();

        if (response.status === 401) {
            localStorage.removeItem("accessToken");
            localStorage.removeItem("adminLoggedIn");
            localStorage.removeItem("userRole");

            window.location.href = "adminlogin.html";
            return;
        }

        if (!response.ok) {
            console.error("Update Warehouse API Error:", data);

            alert(
                data.detail ||
                "Unable to update warehouse."
            );

            return;
        }

        alert("Warehouse updated successfully!");

        showWarehousesPage();

    } catch (error) {

        console.error("Update Warehouse Error:", error);

        alert("Unable to connect to the backend.");
    }
}


async function saveWarehouse() {

    const token =
        localStorage.getItem("accessToken");

    if (!token) {
        window.location.href = "adminlogin.html";
        return;
    }

    const code =
        document.getElementById("warehouseCode").value.trim();

    const name =
        document.getElementById("warehouseName").value.trim();

    const location =
        document.getElementById("warehouseLocation").value.trim();

    const capacity =
        Number(
            document.getElementById("warehouseCapacity").value
        );

    if (!code || !name || !location) {
        alert("Please fill all warehouse details.");
        return;
    }

    if (!Number.isFinite(capacity) || capacity < 0) {
        alert("Capacity must be a valid number.");
        return;
    }

    try {

        const response = await fetch(
            "http://127.0.0.1:8000/api/warehouses",
            {
                method: "POST",

                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${token}`
                },

                body: JSON.stringify({
                    warehouse_code: code,
                    warehouse_name: name,
                    location: location,
                    capacity: capacity,
                    status: "Active"
                })
            }
        );

        const data =
            await response.json();

        if (response.status === 401) {

            localStorage.removeItem("accessToken");
            localStorage.removeItem("adminLoggedIn");
            localStorage.removeItem("userRole");

            window.location.href =
                "adminlogin.html";

            return;
        }

        if (!response.ok) {

            console.error(
                "Add Warehouse API Error:",
                data
            );

            alert(
                data.detail ||
                "Unable to add warehouse."
            );

            return;
        }

        alert(
            "Warehouse added successfully!"
        );

        showWarehousesPage();

    } catch (error) {

        console.error(
            "Add Warehouse Error:",
            error
        );

        alert(
            "Unable to connect to the backend."
        );
    }
}

// ============================================================
// 22. STAFF
// ============================================================

// ============================================================
// 22. STAFF
// ============================================================

function showStaffPage() {

    const content = getAdminContentArea();

    if (!content) {
        console.error("Admin content area not found.");
        return;
    }

    hideOriginalAdminContent();

    content.innerHTML = `

        <div class="page-header">

            <div>
                <h2>👥 Staff Management</h2>
                <p>Manage warehouse staff members</p>
            </div>

            <button
                class="add-btn"
                onclick="showStaffForm()">

                + Add Staff

            </button>

        </div>


        <div class="search-container">

            <input
                type="text"
                id="staffSearch"
                placeholder="Search staff by name, ID, phone or email..."
                oninput="loadStaff(this.value)"
            >

        </div>


        <div id="staffFormContainer"></div>


        <div
            id="staffCardsContainer"
            class="staff-cards-container">

            <div class="staff-loading">
                Loading staff...
            </div>

        </div>

    `;

    loadStaff();
}


async function loadStaff(searchTerm = "") {

    const token =
        localStorage.getItem("accessToken");

    if (!token) {
        window.location.href = "adminlogin.html";
        return;
    }

    try {

        const response = await fetch(
            "http://127.0.0.1:8000/api/staff",
            {
                method: "GET",

                headers: {
                    "Authorization":
                        `Bearer ${token}`
                }
            }
        );


        const data =
            await response.json();


        if (response.status === 401) {

            localStorage.removeItem(
                "accessToken"
            );

            localStorage.removeItem(
                "adminLoggedIn"
            );

            localStorage.removeItem(
                "userRole"
            );

            window.location.href =
                "adminlogin.html";

            return;
        }


        if (!response.ok) {

            alert(
                data.detail ||
                "Unable to load staff."
            );

            return;
        }


        const staffList =
            data.staff || [];


        /* LOAD WAREHOUSES */

        let warehouses = [];

        try {

            const warehouseResponse =
                await fetch(
                    "http://127.0.0.1:8000/api/warehouses",
                    {
                        method: "GET",

                        headers: {
                            "Authorization":
                                `Bearer ${token}`
                        }
                    }
                );


            if (warehouseResponse.ok) {

                const warehouseData =
                    await warehouseResponse.json();

                warehouses =
                    warehouseData.warehouses || [];
            }

        } catch (error) {

            console.error(
                "Warehouse Load Error:",
                error
            );
        }


        function getWarehouseName(warehouseId) {

            if (
                warehouseId === null ||
                warehouseId === undefined ||
                warehouseId === ""
            ) {
                return "Not Assigned";
            }


            const warehouse =
                warehouses.find(
                    function (item) {

                        return Number(
                            item.warehouse_id
                        ) === Number(
                            warehouseId
                        );

                    }
                );


            return warehouse
                ? warehouse.warehouse_name
                : "Not Assigned";
        }


        /* SEARCH */

        const search =
            searchTerm
                .toLowerCase()
                .trim();


        const filteredStaff =
            staffList.filter(
                function (staff) {

                    return (

                        String(
                            staff.staff_code || ""
                        )
                        .toLowerCase()
                        .includes(search)

                        ||

                        String(
                            staff.name || ""
                        )
                        .toLowerCase()
                        .includes(search)

                        ||

                        String(
                            staff.phone || ""
                        )
                        .toLowerCase()
                        .includes(search)

                        ||

                        String(
                            staff.email || ""
                        )
                        .toLowerCase()
                        .includes(search)

                        ||

                        String(
                            staff.status || ""
                        )
                        .toLowerCase()
                        .includes(search)

                        ||

                        String(
                            staff.warehouse_id || ""
                        )
                        .toLowerCase()
                        .includes(search)

                    );

                }
            );


        const container =
            document.getElementById(
                "staffCardsContainer"
            );


        if (!container) {
            return;
        }


        if (filteredStaff.length === 0) {

            container.innerHTML = `

                <div class="staff-empty">

                    👥

                    <h3>
                        No Staff Found
                    </h3>

                    <p>
                        No staff members match your search.
                    </p>

                </div>

            `;

            return;
        }


        /* STAFF CARDS */

        container.innerHTML =
            filteredStaff.map(
                function (staff) {

                    const status =
                        String(
                            staff.status || "Active"
                        );


                    const statusClass =
                        status.toLowerCase() ===
                        "active"
                            ? "active"
                            : "inactive";


                    return `

                        <div class="staff-card">

                            <div class="staff-card-top">

                                <div class="staff-avatar">
                                    👨‍💼
                                </div>

                                <div class="staff-main-info">

                                    <h3>
                                        ${escapeHTML(
                                            staff.name || "Unknown Staff"
                                        )}
                                    </h3>

                                    <span class="staff-code">
                                        ${escapeHTML(
                                            staff.staff_code || ""
                                        )}
                                    </span>

                                </div>

                                <span
                                    class="staff-status ${statusClass}">

                                    ${escapeHTML(status)}

                                </span>

                            </div>


                            <div class="staff-details">

                                <div class="staff-detail">

                                    <span class="detail-icon">
                                        🆔
                                    </span>

                                    <div>
                                        <small>Staff ID</small>
                                        <strong>
                                            ${staff.staff_id}
                                        </strong>
                                    </div>

                                </div>


                                <div class="staff-detail">

                                    <span class="detail-icon">
                                        🏭
                                    </span>

                                    <div>
                                        <small>Warehouse</small>
                                        <strong>
                                            ${escapeHTML(
                                                getWarehouseName(
                                                    staff.warehouse_id
                                                )
                                            )}
                                        </strong>
                                    </div>

                                </div>


                                <div class="staff-detail">

                                    <span class="detail-icon">
                                        📞
                                    </span>

                                    <div>
                                        <small>Phone</small>
                                        <strong>
                                            ${escapeHTML(
                                                staff.phone || "Not Available"
                                            )}
                                        </strong>
                                    </div>

                                </div>


                                <div class="staff-detail">

                                    <span class="detail-icon">
                                        ✉️
                                    </span>

                                    <div>
                                        <small>Email</small>
                                        <strong>
                                            ${escapeHTML(
                                                staff.email || "Not Available"
                                            )}
                                        </strong>
                                    </div>

                                </div>

                            </div>


                            <div class="staff-actions">

                                <button
                                    class="edit-btn"
                                    onclick="editStaff(${staff.staff_id})">

                                    ✏️ Edit

                                </button>


                                <button
                                    class="delete-btn"
                                    onclick="deleteStaff(${staff.staff_id})">

                                    🗑️ Delete

                                </button>

                            </div>

                        </div>

                    `;

                }
            ).join("");

    } catch (error) {

        console.error(
            "Load Staff Error:",
            error
        );

        alert(
            "Unable to connect to the backend."
        );
    }
}


/* ============================================================
   ADD / EDIT STAFF FORM
   ============================================================ */

function showStaffForm(staff = null) {

    const container =
        document.getElementById(
            "staffFormContainer"
        );

    if (!container) {
        return;
    }


    const isEdit =
        staff !== null;


    container.innerHTML = `

        <div class="staff-form">

            <h3>
                ${isEdit
                    ? "✏️ Edit Staff"
                    : "➕ Add New Staff"}
            </h3>


            <div class="form-grid">

                <div>

                    <label>
                        Staff Code
                    </label>

                    <input
                        type="text"
                        id="staffCode"
                        placeholder="STAFF001"
                        value="${
                            isEdit
                                ? escapeHTML(
                                    staff.staff_code || ""
                                )
                                : ""
                        }"
                        ${isEdit ? "readonly" : ""}
                    >

                </div>


                <div>

                    <label>
                        Name
                    </label>

                    <input
                        type="text"
                        id="staffName"
                        placeholder="Staff Name"
                        value="${
                            isEdit
                                ? escapeHTML(
                                    staff.name || ""
                                )
                                : ""
                        }"
                    >

                </div>


                <div>

                    <label>
                        Password
                    </label>

                    <input
                        type="password"
                        id="staffFormPassword"
                        placeholder="${
                            isEdit
                                ? "Enter new password"
                                : "Enter password"
                        }"
                    >

                </div>


                <div>

                    <label>
                        Phone
                    </label>

                    <input
                        type="text"
                        id="staffPhone"
                        placeholder="Phone number"
                        value="${
                            isEdit
                                ? escapeHTML(
                                    staff.phone || ""
                                )
                                : ""
                        }"
                    >

                </div>


                <div>

                    <label>
                        Email
                    </label>

                    <input
                        type="email"
                        id="staffEmail"
                        placeholder="staff@example.com"
                        value="${
                            isEdit
                                ? escapeHTML(
                                    staff.email || ""
                                )
                                : ""
                        }"
                    >

                </div>


                <div>

                    <label>
                        Warehouse ID
                    </label>

                    <input
                        type="number"
                        id="staffWarehouse"
                        placeholder="1"
                        min="1"
                        value="${
                            isEdit &&
                            staff.warehouse_id != null
                                ? staff.warehouse_id
                                : ""
                        }"
                    >

                </div>


                <div>

                    <label>
                        Status
                    </label>

                    <select id="staffStatus">

                        <option
                            value="Active"
                            ${
                                !isEdit ||
                                staff.status === "Active"
                                    ? "selected"
                                    : ""
                            }>

                            Active

                        </option>

                        <option
                            value="Inactive"
                            ${
                                isEdit &&
                                staff.status === "Inactive"
                                    ? "selected"
                                    : ""
                            }>

                            Inactive

                        </option>

                    </select>

                </div>

            </div>


            <div class="staff-form-buttons">

                <button
                    class="add-product-btn"
                    onclick="${
                        isEdit
                            ? `updateStaff(${staff.staff_id})`
                            : "saveStaff()"
                    }">

                    ${
                        isEdit
                            ? "Update Staff"
                            : "Save Staff"
                    }

                </button>


                <button
                    type="button"
                    onclick="cancelStaffForm()">

                    Cancel

                </button>

            </div>

        </div>

    `;


    container.scrollIntoView({
        behavior: "smooth",
        block: "start"
    });
}


/* ============================================================
   SAVE STAFF
   ============================================================ */

async function saveStaff() {

    const token =
        localStorage.getItem(
            "accessToken"
        );


    if (!token) {

        window.location.href =
            "adminlogin.html";

        return;
    }


    const staffCode =
        document.getElementById(
            "staffCode"
        ).value.trim();


    const name =
        document.getElementById(
            "staffName"
        ).value.trim();


    const password =
        document.getElementById(
            "staffFormPassword"
        ).value;


    const phone =
        document.getElementById(
            "staffPhone"
        ).value.trim();


    const email =
        document.getElementById(
            "staffEmail"
        ).value.trim();


    const warehouseValue =
        document.getElementById(
            "staffWarehouse"
        ).value.trim();


    const status =
        document.getElementById(
            "staffStatus"
        ).value;


    if (
        !staffCode ||
        !name ||
        !password ||
        !phone ||
        !email
    ) {

        alert(
            "Please fill all required staff details."
        );

        return;
    }


    const warehouseId =
        warehouseValue === ""
            ? null
            : Number(warehouseValue);


    if (
        warehouseId !== null &&
        (
            !Number.isInteger(warehouseId) ||
            warehouseId <= 0
        )
    ) {

        alert(
            "Warehouse ID must be a valid number."
        );

        return;
    }


    try {

        const response =
            await fetch(
                "http://127.0.0.1:8000/api/staff",
                {
                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/json",

                        "Authorization":
                            `Bearer ${token}`
                    },

                    body: JSON.stringify({

                        staff_code:
                            staffCode,

                        name:
                            name,

                        password:
                            password,

                        phone:
                            phone,

                        email:
                            email,

                        warehouse_id:
                            warehouseId,

                        status:
                            status

                    })
                }
            );


        const data =
            await response.json();


        if (response.status === 401) {

            localStorage.removeItem(
                "accessToken"
            );

            localStorage.removeItem(
                "adminLoggedIn"
            );

            localStorage.removeItem(
                "userRole"
            );

            window.location.href =
                "adminlogin.html";

            return;
        }


        if (!response.ok) {

            alert(
                data.detail ||
                "Unable to add staff."
            );

            return;
        }


        alert(
            "Staff added successfully!"
        );


        showStaffPage();

    } catch (error) {

        console.error(
            "Add Staff Error:",
            error
        );

        alert(
            "Unable to connect to the backend."
        );
    }
}


/* ============================================================
   CANCEL FORM
   ============================================================ */

function cancelStaffForm() {

    const container =
        document.getElementById(
            "staffFormContainer"
        );

    if (container) {
        container.innerHTML = "";
    }
}


/* ============================================================
   EDIT STAFF
   ============================================================ */

async function editStaff(id) {

    const token =
        localStorage.getItem(
            "accessToken"
        );


    if (!token) {

        window.location.href =
            "adminlogin.html";

        return;
    }


    try {

        const response =
            await fetch(
                `http://127.0.0.1:8000/api/staff/${id}`,
                {
                    method: "GET",

                    headers: {
                        "Authorization":
                            `Bearer ${token}`
                    }
                }
            );


        const data =
            await response.json();


        if (response.status === 401) {

            localStorage.removeItem(
                "accessToken"
            );

            localStorage.removeItem(
                "adminLoggedIn"
            );

            localStorage.removeItem(
                "userRole"
            );

            window.location.href =
                "adminlogin.html";

            return;
        }


        if (!response.ok) {

            alert(
                data.detail ||
                "Unable to load staff."
            );

            return;
        }


        const staff =
            data.staff || data;


        showStaffForm(staff);

    } catch (error) {

        console.error(
            "Edit Staff Error:",
            error
        );

        alert(
            "Unable to connect to the backend."
        );
    }
}


/* ============================================================
   UPDATE STAFF
   ============================================================ */

async function updateStaff(id) {

    const token =
        localStorage.getItem(
            "accessToken"
        );


    if (!token) {

        window.location.href =
            "adminlogin.html";

        return;
    }


    const name =
        document.getElementById(
            "staffName"
        ).value.trim();


    const password =
        document.getElementById(
            "staffFormPassword"
        ).value;


    const phone =
        document.getElementById(
            "staffPhone"
        ).value.trim();


    const email =
        document.getElementById(
            "staffEmail"
        ).value.trim();


    const warehouseValue =
        document.getElementById(
            "staffWarehouse"
        ).value.trim();


    const status =
        document.getElementById(
            "staffStatus"
        ).value;


    if (
        !name ||
        !phone ||
        !email
    ) {

        alert(
            "Please fill all required staff details."
        );

        return;
    }


    const warehouseId =
        warehouseValue === ""
            ? null
            : Number(warehouseValue);


    if (
        warehouseId !== null &&
        (
            !Number.isInteger(warehouseId) ||
            warehouseId <= 0
        )
    ) {

        alert(
            "Warehouse ID must be a valid number."
        );

        return;
    }


    const body = {

        name:
            name,

        phone:
            phone,

        email:
            email,

        warehouse_id:
            warehouseId,

        status:
            status

    };


    if (password) {
        body.password = password;
    }


    try {

        const response =
            await fetch(
                `http://127.0.0.1:8000/api/staff/${id}`,
                {
                    method: "PUT",

                    headers: {
                        "Content-Type":
                            "application/json",

                        "Authorization":
                            `Bearer ${token}`
                    },

                    body:
                        JSON.stringify(body)
                }
            );


        const data =
            await response.json();


        if (response.status === 401) {

            localStorage.removeItem(
                "accessToken"
            );

            localStorage.removeItem(
                "adminLoggedIn"
            );

            localStorage.removeItem(
                "userRole"
            );

            window.location.href =
                "adminlogin.html";

            return;
        }


        if (!response.ok) {

            alert(
                data.detail ||
                "Unable to update staff."
            );

            return;
        }


        alert(
            "Staff updated successfully!"
        );


        showStaffPage();

    } catch (error) {

        console.error(
            "Update Staff Error:",
            error
        );

        alert(
            "Unable to connect to the backend."
        );
    }
}


/* ============================================================
   DELETE STAFF
   ============================================================ */

async function deleteStaff(id) {

    const token =
        localStorage.getItem(
            "accessToken"
        );


    if (!token) {

        window.location.href =
            "adminlogin.html";

        return;
    }


    const confirmDelete =
        confirm(
            "Are you sure you want to delete this staff member?"
        );


    if (!confirmDelete) {
        return;
    }


    try {

        const response =
            await fetch(
                `http://127.0.0.1:8000/api/staff/${id}`,
                {
                    method: "DELETE",

                    headers: {
                        "Authorization":
                            `Bearer ${token}`
                    }
                }
            );


        const data =
            await response.json();


        if (response.status === 401) {

            localStorage.removeItem(
                "accessToken"
            );

            localStorage.removeItem(
                "adminLoggedIn"
            );

            localStorage.removeItem(
                "userRole"
            );

            window.location.href =
                "adminlogin.html";

            return;
        }


        if (!response.ok) {

            alert(
                data.detail ||
                "Unable to delete staff."
            );

            return;
        }


        alert(
            "Staff deleted successfully!"
        );


        showStaffPage();

    } catch (error) {

        console.error(
            "Delete Staff Error:",
            error
        );

        alert(
            "Unable to connect to the backend."
        );
    }
}

// ============================================================
// 23. SUPPLIERS
// ============================================================

// ============================================================
// 23. SUPPLIERS
// ============================================================

function showSuppliersPage() {

    const content = getAdminContentArea();

    if (!content) {
        console.error("Admin content area not found.");
        return;
    }

    hideOriginalAdminContent();

    content.innerHTML = `

        <div class="page-header">

            <div>
                <h2>🚚 Supplier Network</h2>
                <p>Manage and connect with your trusted suppliers</p>
            </div>

            <button
                class="add-btn"
                onclick="showSupplierForm()"
            >
                + Add Supplier
            </button>

        </div>


        <div class="supplier-toolbar">

            <div class="supplier-search-box">

                🔍

                <input
                    type="text"
                    id="supplierSearch"
                    placeholder="Search suppliers..."
                    oninput="loadSuppliers(this.value)"
                >

            </div>

            <div class="supplier-status-info">
                <span>🟢 Active</span>
                <span>🔴 Inactive</span>
            </div>

        </div>


        <div id="supplierFormContainer"></div>


        <div class="supplier-section-title">
            <h3>Supplier Network</h3>
        </div>


        <div
            id="supplierCardsContainer"
            class="supplier-cards-container"
        >
            <div class="supplier-loading">
                Loading suppliers...
            </div>
        </div>

    `;

    loadSuppliers();
}


async function loadSuppliers(searchTerm = "") {

    const token =
        localStorage.getItem("accessToken");

    if (!token) {
        window.location.href = "adminlogin.html";
        return;
    }

    try {

        const response = await fetch(
            "http://127.0.0.1:8000/api/suppliers",
            {
                method: "GET",

                headers: {
                    "Authorization":
                        `Bearer ${token}`
                }
            }
        );


        const data =
            await response.json();


        if (response.status === 401) {

            localStorage.removeItem("accessToken");
            localStorage.removeItem("adminLoggedIn");
            localStorage.removeItem("userRole");

            window.location.href =
                "adminlogin.html";

            return;
        }


        if (!response.ok) {

            console.error(
                "Supplier API Error:",
                data
            );

            alert(
                data.detail ||
                "Unable to load suppliers."
            );

            return;
        }


        const suppliers =
            data.suppliers || [];


        const search =
            searchTerm
                .toLowerCase()
                .trim();


        const filteredSuppliers =
            suppliers.filter(function (supplier) {

                return (

                    String(
                        supplier.supplier_code || ""
                    )
                    .toLowerCase()
                    .includes(search)

                    ||

                    String(
                        supplier.supplier_name || ""
                    )
                    .toLowerCase()
                    .includes(search)

                    ||

                    String(
                        supplier.contact || ""
                    )
                    .toLowerCase()
                    .includes(search)

                    ||

                    String(
                        supplier.email || ""
                    )
                    .toLowerCase()
                    .includes(search)

                    ||

                    String(
                        supplier.address || ""
                    )
                    .toLowerCase()
                    .includes(search)

                    ||

                    String(
                        supplier.status || ""
                    )
                    .toLowerCase()
                    .includes(search)

                );

            });


        const container =
            document.getElementById(
                "supplierCardsContainer"
            );


        if (!container) {
            return;
        }


        if (!filteredSuppliers.length) {

            container.innerHTML = `

                <div class="supplier-empty">

                    <div class="supplier-empty-icon">
                        🚚
                    </div>

                    <h3>No suppliers found</h3>

                    <p>
                        Try a different search or add a new supplier.
                    </p>

                </div>

            `;

            return;
        }


        container.innerHTML =
            filteredSuppliers
                .map(function (supplier) {

                    const status =
                        String(
                            supplier.status || "Inactive"
                        );

                    const isActive =
                        status.toLowerCase() === "active";


                    return `

                        <div class="supplier-card">

                            <div class="supplier-card-header">

                                <div class="supplier-company-icon">
                                    🏢
                                </div>

                                <div class="supplier-title">

                                    <h3>
                                        ${escapeHTML(
                                            supplier.supplier_name || ""
                                        )}
                                    </h3>

                                    <span class="supplier-code">
                                        ${escapeHTML(
                                            supplier.supplier_code || ""
                                        )}
                                    </span>

                                </div>

                                <span
                                    class="supplier-status ${
                                        isActive
                                            ? "active"
                                            : "inactive"
                                    }"
                                >
                                    ${isActive ? "🟢" : "🔴"}
                                    ${escapeHTML(status)}
                                </span>

                            </div>


                            <div class="supplier-divider"></div>


                            <div class="supplier-details">

                                <div class="supplier-detail">

                                    <span class="supplier-detail-icon">
                                        📞
                                    </span>

                                    <div>
                                        <small>Contact</small>

                                        <strong>
                                            ${escapeHTML(
                                                supplier.contact || "N/A"
                                            )}
                                        </strong>
                                    </div>

                                </div>


                                <div class="supplier-detail">

                                    <span class="supplier-detail-icon">
                                        ✉️
                                    </span>

                                    <div>
                                        <small>Email</small>

                                        <strong>
                                            ${escapeHTML(
                                                supplier.email || "N/A"
                                            )}
                                        </strong>
                                    </div>

                                </div>


                                <div class="supplier-detail supplier-address">

                                    <span class="supplier-detail-icon">
                                        📍
                                    </span>

                                    <div>
                                        <small>Address</small>

                                        <strong>
                                            ${escapeHTML(
                                                supplier.address || "N/A"
                                            )}
                                        </strong>
                                    </div>

                                </div>

                            </div>


                            <div class="supplier-card-footer">

                                <div class="supplier-label">
                                    <span>📦</span>
                                    <span>Supplier</span>
                                </div>


                                <div class="supplier-actions">

                                    <button
                                        class="supplier-edit-btn"
                                        onclick="editSupplier(
                                            ${supplier.supplier_id}
                                        )"
                                    >
                                        ✏️ Edit
                                    </button>


                                    <button
                                        class="supplier-delete-btn"
                                        onclick="deleteSupplier(
                                            ${supplier.supplier_id}
                                        )"
                                    >
                                        🗑️ Delete
                                    </button>

                                </div>

                            </div>

                        </div>

                    `;

                })
                .join("");

    } catch (error) {

        console.error(
            "Load Suppliers Error:",
            error
        );

        alert(
            "Unable to connect to the backend."
        );
    }
}


async function editSupplier(id) {

    const token =
        localStorage.getItem("accessToken");

    if (!token) {
        window.location.href = "adminlogin.html";
        return;
    }

    try {

        const response = await fetch(
            `http://127.0.0.1:8000/api/suppliers/${id}`,
            {
                method: "GET",

                headers: {
                    "Authorization":
                        `Bearer ${token}`
                }
            }
        );


        const data =
            await response.json();


        if (response.status === 401) {

            localStorage.removeItem("accessToken");
            localStorage.removeItem("adminLoggedIn");
            localStorage.removeItem("userRole");

            window.location.href =
                "adminlogin.html";

            return;
        }


        if (!response.ok) {

            alert(
                data.detail ||
                "Unable to load supplier."
            );

            return;
        }


        const supplier =
            data.supplier || data;

        showSupplierForm(supplier);

    } catch (error) {

        console.error(
            "Edit Supplier Error:",
            error
        );

        alert(
            "Unable to connect to the backend."
        );
    }
}


function showSupplierForm(supplier = null) {

    const container =
        document.getElementById(
            "supplierFormContainer"
        );

    if (!container) {
        return;
    }


    const isEdit = !!supplier;


    container.innerHTML = `

        <div class="product-form">

            <h3>
                ${isEdit
                    ? "Edit Supplier"
                    : "Add Supplier"}
            </h3>


            <div class="form-grid">

                <div>

                    <label>Supplier Code</label>

                    <input
                        type="text"
                        id="supplierCode"
                        placeholder="SUP021"
                        value="${
                            isEdit
                                ? escapeHTML(
                                    supplier.supplier_code || ""
                                  )
                                : ""
                        }"
                        ${isEdit ? "readonly" : ""}
                    >

                </div>


                <div>

                    <label>Supplier Name</label>

                    <input
                        type="text"
                        id="supplierName"
                        placeholder="Supplier Name"
                        value="${
                            isEdit
                                ? escapeHTML(
                                    supplier.supplier_name || ""
                                  )
                                : ""
                        }"
                    >

                </div>


                <div>

                    <label>Contact</label>

                    <input
                        type="text"
                        id="supplierContact"
                        placeholder="9876543210"
                        value="${
                            isEdit
                                ? escapeHTML(
                                    supplier.contact || ""
                                  )
                                : ""
                        }"
                    >

                </div>


                <div>

                    <label>Email</label>

                    <input
                        type="email"
                        id="supplierEmail"
                        placeholder="supplier@example.com"
                        value="${
                            isEdit
                                ? escapeHTML(
                                    supplier.email || ""
                                  )
                                : ""
                        }"
                    >

                </div>


                <div>

                    <label>Address</label>

                    <input
                        type="text"
                        id="supplierAddress"
                        placeholder="Hyderabad"
                        value="${
                            isEdit
                                ? escapeHTML(
                                    supplier.address || ""
                                  )
                                : ""
                        }"
                    >

                </div>


                <div>

                    <label>Status</label>

                    <select id="supplierStatus">

                        <option
                            value="Active"
                            ${
                                !isEdit ||
                                supplier.status === "Active"
                                    ? "selected"
                                    : ""
                            }
                        >
                            Active
                        </option>

                        <option
                            value="Inactive"
                            ${
                                isEdit &&
                                supplier.status === "Inactive"
                                    ? "selected"
                                    : ""
                            }
                        >
                            Inactive
                        </option>

                    </select>

                </div>

            </div>


            <div style="margin-top:15px;">

                <button
                    class="add-product-btn"
                    onclick="${
                        isEdit
                            ? `updateSupplier(${supplier.supplier_id})`
                            : "saveSupplier()"
                    }"
                >
                    ${
                        isEdit
                            ? "Update Supplier"
                            : "Save Supplier"
                    }
                </button>


                <button
                    type="button"
                    onclick="cancelSupplierForm()"
                >
                    Cancel
                </button>

            </div>

        </div>

    `;


    container.scrollIntoView({
        behavior: "smooth",
        block: "start"
    });
}


async function saveSupplier() {

    const token =
        localStorage.getItem("accessToken");

    if (!token) {
        window.location.href = "adminlogin.html";
        return;
    }


    const supplierCode =
        document.getElementById(
            "supplierCode"
        ).value.trim();

    const supplierName =
        document.getElementById(
            "supplierName"
        ).value.trim();

    const contact =
        document.getElementById(
            "supplierContact"
        ).value.trim();

    const email =
        document.getElementById(
            "supplierEmail"
        ).value.trim();

    const address =
        document.getElementById(
            "supplierAddress"
        ).value.trim();

    const status =
        document.getElementById(
            "supplierStatus"
        ).value;


    if (!supplierCode ||
        !supplierName ||
        !contact ||
        !email ||
        !address) {

        alert(
            "Please fill all supplier fields."
        );

        return;
    }


    try {

        const response = await fetch(
            "http://127.0.0.1:8000/api/suppliers",
            {
                method: "POST",

                headers: {
                    "Content-Type":
                        "application/json",

                    "Authorization":
                        `Bearer ${token}`
                },

                body: JSON.stringify({

                    supplier_code:
                        supplierCode,

                    supplier_name:
                        supplierName,

                    contact:
                        contact,

                    email:
                        email,

                    address:
                        address,

                    status:
                        status

                })
            }
        );


        const data =
            await response.json();


        if (response.status === 401) {

            localStorage.removeItem("accessToken");
            localStorage.removeItem("adminLoggedIn");
            localStorage.removeItem("userRole");

            window.location.href =
                "adminlogin.html";

            return;
        }


        if (!response.ok) {

            alert(
                data.detail ||
                "Unable to add supplier."
            );

            return;
        }


        alert(
            "Supplier added successfully!"
        );

        showSuppliersPage();

    } catch (error) {

        console.error(
            "Save Supplier Error:",
            error
        );

        alert(
            "Unable to connect to the backend."
        );
    }
}


function cancelSupplierForm() {

    const container =
        document.getElementById(
            "supplierFormContainer"
        );

    if (container) {
        container.innerHTML = "";
    }
}


async function updateSupplier(id) {

    const token =
        localStorage.getItem("accessToken");

    if (!token) {
        window.location.href = "adminlogin.html";
        return;
    }


    const supplierName =
        document.getElementById(
            "supplierName"
        ).value.trim();

    const contact =
        document.getElementById(
            "supplierContact"
        ).value.trim();

    const email =
        document.getElementById(
            "supplierEmail"
        ).value.trim();

    const address =
        document.getElementById(
            "supplierAddress"
        ).value.trim();

    const status =
        document.getElementById(
            "supplierStatus"
        ).value;


    if (!supplierName ||
        !contact ||
        !email ||
        !address) {

        alert(
            "Please fill all supplier fields."
        );

        return;
    }


    try {

        const response = await fetch(
            `http://127.0.0.1:8000/api/suppliers/${id}`,
            {
                method: "PUT",

                headers: {
                    "Content-Type":
                        "application/json",

                    "Authorization":
                        `Bearer ${token}`
                },

                body: JSON.stringify({

                    supplier_name:
                        supplierName,

                    contact:
                        contact,

                    email:
                        email,

                    address:
                        address,

                    status:
                        status

                })
            }
        );


        const data =
            await response.json();


        if (response.status === 401) {

            localStorage.removeItem("accessToken");
            localStorage.removeItem("adminLoggedIn");
            localStorage.removeItem("userRole");

            window.location.href =
                "adminlogin.html";

            return;
        }


        if (!response.ok) {

            alert(
                data.detail ||
                "Unable to update supplier."
            );

            return;
        }


        alert(
            "Supplier updated successfully!"
        );

        showSuppliersPage();

    } catch (error) {

        console.error(
            "Update Supplier Error:",
            error
        );

        alert(
            "Unable to connect to the backend."
        );
    }
}


async function deleteSupplier(id) {

    const token =
        localStorage.getItem("accessToken");

    if (!token) {
        window.location.href = "adminlogin.html";
        return;
    }


    const confirmDelete =
        confirm(
            "Are you sure you want to delete this supplier?"
        );


    if (!confirmDelete) {
        return;
    }


    try {

        const response = await fetch(
            `http://127.0.0.1:8000/api/suppliers/${id}`,
            {
                method: "DELETE",

                headers: {
                    "Authorization":
                        `Bearer ${token}`
                }
            }
        );


        const data =
            await response.json();


        if (response.status === 401) {

            localStorage.removeItem("accessToken");
            localStorage.removeItem("adminLoggedIn");
            localStorage.removeItem("userRole");

            window.location.href =
                "adminlogin.html";

            return;
        }


        if (!response.ok) {

            alert(
                data.detail ||
                "Unable to delete supplier."
            );

            return;
        }


        alert(
            "Supplier deleted successfully!"
        );

        showSuppliersPage();

    } catch (error) {

        console.error(
            "Delete Supplier Error:",
            error
        );

        alert(
            "Unable to connect to the backend."
        );
    }
}

// ============================================================
// 24. STOCK IN
// ============================================================

async function showStockInPage() {

    const content = getAdminContentArea();

    if (!content) return;

    hideOriginalAdminContent();

    const token = localStorage.getItem("accessToken");

    if (!token) {
        window.location.href = "adminlogin.html";
        return;
    }

    content.innerHTML = `
        <div class="panel">

            <h2>📥 Stock In</h2>

            <p>Add incoming stock to a product.</p>

            <div style="margin-top:20px; max-width:500px;">

                <div class="form-group" style="margin-bottom:15px;">
                    <label>Select Product</label>

                    <select
                        id="stockInProduct"
                        class="input-wrapper"
                        style="width:100%; height:45px;"
                    >
                        <option value="">Loading products...</option>
                    </select>
                </div>


                <div class="form-group" style="margin-bottom:15px;">

                    <label>Warehouse ID</label>

                    <input
                        type="number"
                        id="stockInWarehouse"
                        placeholder="Enter warehouse ID"
                        min="1"
                        class="input-wrapper"
                        style="width:100%; height:45px;"
                    >

                </div>


                <div class="form-group" style="margin-bottom:15px;">

                    <label>Quantity to Add</label>

                    <input
                        type="number"
                        id="stockInQuantity"
                        placeholder="Enter quantity"
                        min="1"
                        class="input-wrapper"
                        style="width:100%; height:45px;"
                    >

                </div>


                <div class="form-group" style="margin-bottom:15px;">

                    <label>Remarks</label>

                    <input
                        type="text"
                        id="stockInRemarks"
                        placeholder="Enter remarks"
                        class="input-wrapper"
                        style="width:100%; height:45px;"
                    >

                </div>


                <button
                    class="save-btn"
                    onclick="executeStockIn()"
                >
                    Submit Stock In
                </button>

            </div>

        </div>
    `;


    try {

        const response = await fetch(
            "http://127.0.0.1:8000/api/products",
            {
                headers: {
                    "Authorization": `Bearer ${token}`
                }
            }
        );

        const data = await response.json();

        if (response.status === 401) {

            localStorage.removeItem("accessToken");
            localStorage.removeItem("adminLoggedIn");
            localStorage.removeItem("userRole");

            window.location.href = "adminlogin.html";

            return;
        }

        if (!response.ok) {

            alert(data.detail || "Unable to load products.");
            return;
        }

        const products = data.products || [];

        const select = document.getElementById("stockInProduct");

        if (!select) return;

        if (!products.length) {

            select.innerHTML =
                `<option value="">No products available</option>`;

            return;
        }

        select.innerHTML = `
            <option value="">Select Product</option>

            ${products.map(function(product) {

                return `
                    <option value="${product.product_id}">
                        ${escapeHTML(product.product_code)}
                        - ${escapeHTML(product.product_name)}
                        (Current: ${Number(product.quantity || 0)})
                    </option>
                `;

            }).join("")}
        `;

    } catch (error) {

        console.error("Load Stock In Products Error:", error);

        alert("Unable to connect to the backend.");
    }
}

async function executeStockIn() {

    const token = localStorage.getItem("accessToken");

    if (!token) {

        window.location.href = "adminlogin.html";

        return;
    }


    const productId =
        Number(document.getElementById("stockInProduct").value);

    const warehouseId =
        Number(document.getElementById("stockInWarehouse").value);

    const quantity =
        Number(document.getElementById("stockInQuantity").value);

    const remarks =
        document.getElementById("stockInRemarks").value.trim();


    if (!productId) {

        alert("Please select a product.");

        return;
    }


    if (!warehouseId || warehouseId <= 0) {

        alert("Please enter a valid warehouse ID.");

        return;
    }


    if (!quantity || quantity <= 0) {

        alert("Please enter a valid quantity.");

        return;
    }


    try {

        const response = await fetch(
            "http://127.0.0.1:8000/api/stock",
            {
                method: "POST",

                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${token}`
                },

                body: JSON.stringify({

                    product_id: productId,

                    warehouse_id: warehouseId,

                    staff_id: 1,

                    transaction_type: "Stock In",

                    quantity: quantity,

                    remarks: remarks || "Stock In from Admin Dashboard"

                })
            }
        );


        const data = await response.json();


        if (response.status === 401) {

            localStorage.removeItem("accessToken");
            localStorage.removeItem("adminLoggedIn");
            localStorage.removeItem("userRole");

            window.location.href = "adminlogin.html";

            return;
        }


        if (!response.ok) {

            console.error("Stock In API Error:", data);

            alert(
                data.detail ||
                "Unable to record Stock In."
            );

            return;
        }


        alert("Stock In recorded successfully!");


        showStockInPage();


    } catch (error) {

        console.error("Stock In Error:", error);

        alert("Unable to connect to the backend.");
    }
}


// ============================================================
// 25. STOCK OUT
// ============================================================

async function showStockOutPage() {

    const content = getAdminContentArea();

    if (!content) return;

    hideOriginalAdminContent();

    const token = localStorage.getItem("accessToken");

    if (!token) {
        window.location.href = "adminlogin.html";
        return;
    }

    content.innerHTML = `
        <div class="panel">

            <h2>📤 Stock Out</h2>

            <p>Remove products from warehouse inventory.</p>

            <div style="margin-top:20px; max-width:500px;">

                <div class="form-group" style="margin-bottom:15px;">
                    <label>Select Product</label>

                    <select
                        id="stockOutProduct"
                        class="input-wrapper"
                        style="width:100%; height:45px;"
                    >
                        <option value="">Loading products...</option>
                    </select>
                </div>

                <div class="form-group" style="margin-bottom:15px;">

                    <label>Warehouse ID</label>

                    <input
                        type="number"
                        id="stockOutWarehouse"
                        placeholder="Enter warehouse ID"
                        min="1"
                        class="input-wrapper"
                        style="width:100%; height:45px;"
                    >

                </div>

                <div class="form-group" style="margin-bottom:15px;">

                    <label>Quantity to Remove</label>

                    <input
                        type="number"
                        id="stockOutQuantity"
                        placeholder="Enter quantity"
                        min="1"
                        class="input-wrapper"
                        style="width:100%; height:45px;"
                    >

                </div>

                <div class="form-group" style="margin-bottom:15px;">

                    <label>Remarks</label>

                    <input
                        type="text"
                        id="stockOutRemarks"
                        placeholder="Enter remarks"
                        class="input-wrapper"
                        style="width:100%; height:45px;"
                    >

                </div>

                <button
                    class="delete-btn"
                    onclick="executeStockOut()"
                >
                    Submit Stock Out
                </button>

            </div>

        </div>
    `;

    try {

        const response = await fetch(
            "http://127.0.0.1:8000/api/products",
            {
                headers: {
                    "Authorization": `Bearer ${token}`
                }
            }
        );

        const data = await response.json();

        if (response.status === 401) {

            localStorage.removeItem("accessToken");
            localStorage.removeItem("adminLoggedIn");
            localStorage.removeItem("userRole");

            window.location.href = "adminlogin.html";

            return;
        }

        if (!response.ok) {

            alert(data.detail || "Unable to load products.");

            return;
        }

        const products = data.products || [];

        const select =
            document.getElementById("stockOutProduct");

        if (!select) return;

        if (!products.length) {

            select.innerHTML =
                `<option value="">No products available</option>`;

            return;
        }

        select.innerHTML = `
            <option value="">Select Product</option>

            ${products.map(function(product) {

                return `
                    <option value="${product.product_id}">
                        ${escapeHTML(product.product_code)}
                        - ${escapeHTML(product.product_name)}
                        (Available: ${Number(product.quantity || 0)})
                    </option>
                `;

            }).join("")}
        `;

    } catch (error) {

        console.error(
            "Load Stock Out Products Error:",
            error
        );

        alert("Unable to connect to the backend.");
    }
}

async function executeStockOut() {

    const token = localStorage.getItem("accessToken");

    if (!token) {

        window.location.href = "adminlogin.html";

        return;
    }

    const productId =
        Number(document.getElementById("stockOutProduct").value);

    const warehouseId =
        Number(document.getElementById("stockOutWarehouse").value);

    const quantity =
        Number(document.getElementById("stockOutQuantity").value);

    const remarks =
        document.getElementById("stockOutRemarks").value.trim();


    if (!productId) {

        alert("Please select a product.");

        return;
    }


    if (!warehouseId || warehouseId <= 0) {

        alert("Please enter a valid warehouse ID.");

        return;
    }


    if (!quantity || quantity <= 0) {

        alert("Please enter a valid quantity.");

        return;
    }


    try {

        const response = await fetch(
            "http://127.0.0.1:8000/api/stock",
            {
                method: "POST",

                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${token}`
                },

                body: JSON.stringify({

                    product_id: productId,

                    warehouse_id: warehouseId,

                    staff_id: 1,

                    transaction_type: "Stock Out",

                    quantity: quantity,

                    remarks: remarks || "Stock Out from Admin Dashboard"

                })
            }
        );


        const data = await response.json();


        if (response.status === 401) {

            localStorage.removeItem("accessToken");
            localStorage.removeItem("adminLoggedIn");
            localStorage.removeItem("userRole");

            window.location.href = "adminlogin.html";

            return;
        }


        if (!response.ok) {

            console.error(
                "Stock Out API Error:",
                data
            );

            alert(
                data.detail ||
                "Unable to record Stock Out."
            );

            return;
        }


        alert("Stock Out recorded successfully!");


        showStockOutPage();

    } catch (error) {

        console.error(
            "Stock Out Error:",
            error
        );

        alert("Unable to connect to the backend.");
    }
}


// ============================================================
// 26. STOCK TRANSFER
// ============================================================
async function showStockTransferPage() {

    const content = getAdminContentArea();

    if (!content) return;

    hideOriginalAdminContent();

    const token = localStorage.getItem("accessToken");

    if (!token) {
        window.location.href = "adminlogin.html";
        return;
    }

    content.innerHTML = `
        <div class="panel">

            <h2>🔄 Stock Transfer</h2>

            <p>Transfer a product from one warehouse to another.</p>

            <div style="margin-top:20px; max-width:500px;">

                <div class="form-group" style="margin-bottom:15px;">
                    <label>Select Product</label>

                    <select
                        id="transferProduct"
                        class="input-wrapper"
                        style="width:100%; height:45px;"
                    >
                        <option value="">Loading products...</option>
                    </select>
                </div>


                <div class="form-group" style="margin-bottom:15px;">

                    <label>From Warehouse ID</label>

                    <input
                        type="number"
                        id="transferFromWarehouse"
                        placeholder="Enter source warehouse ID"
                        min="1"
                        class="input-wrapper"
                        style="width:100%; height:45px;"
                    >

                </div>


                <div class="form-group" style="margin-bottom:15px;">

                    <label>To Warehouse ID</label>

                    <input
                        type="number"
                        id="transferToWarehouse"
                        placeholder="Enter destination warehouse ID"
                        min="1"
                        class="input-wrapper"
                        style="width:100%; height:45px;"
                    >

                </div>


                <div class="form-group" style="margin-bottom:15px;">

                    <label>Quantity</label>

                    <input
                        type="number"
                        id="transferQuantity"
                        placeholder="Enter quantity"
                        min="1"
                        class="input-wrapper"
                        style="width:100%; height:45px;"
                    >

                </div>


                <div class="form-group" style="margin-bottom:15px;">

                    <label>Remarks</label>

                    <input
                        type="text"
                        id="transferRemarks"
                        placeholder="Enter remarks"
                        class="input-wrapper"
                        style="width:100%; height:45px;"
                    >

                </div>


                <button
                    class="save-btn"
                    onclick="executeStockTransfer()"
                >
                    Submit Stock Transfer
                </button>

            </div>

        </div>
    `;


    try {

        const response = await fetch(
            "http://127.0.0.1:8000/api/products",
            {
                headers: {
                    "Authorization": `Bearer ${token}`
                }
            }
        );


        const data = await response.json();


        if (response.status === 401) {

            localStorage.removeItem("accessToken");
            localStorage.removeItem("adminLoggedIn");
            localStorage.removeItem("userRole");

            window.location.href = "adminlogin.html";

            return;
        }


        if (!response.ok) {

            alert(
                data.detail ||
                "Unable to load products."
            );

            return;
        }


        const products = data.products || [];

        const select =
            document.getElementById("transferProduct");


        if (!select) return;


        if (!products.length) {

            select.innerHTML =
                `<option value="">No products available</option>`;

            return;
        }


        select.innerHTML = `
            <option value="">Select Product</option>

            ${products.map(function(product) {

                return `
                    <option value="${product.product_id}">
                        ${escapeHTML(product.product_code)}
                        - ${escapeHTML(product.product_name)}
                        (Warehouse: ${product.warehouse_id})
                    </option>
                `;

            }).join("")}
        `;


    } catch (error) {

        console.error(
            "Load Transfer Products Error:",
            error
        );

        alert("Unable to connect to the backend.");
    }
}

async function executeStockTransfer() {

    const token = localStorage.getItem("accessToken");

    if (!token) {

        window.location.href = "adminlogin.html";

        return;
    }


    const productId =
        Number(document.getElementById("transferProduct").value);

    const fromWarehouseId =
        Number(document.getElementById("transferFromWarehouse").value);

    const toWarehouseId =
        Number(document.getElementById("transferToWarehouse").value);

    const quantity =
        Number(document.getElementById("transferQuantity").value);

    const remarks =
        document.getElementById("transferRemarks").value.trim();


    if (!productId) {

        alert("Please select a product.");

        return;
    }


    if (!fromWarehouseId || fromWarehouseId <= 0) {

        alert("Please enter the source warehouse ID.");

        return;
    }


    if (!toWarehouseId || toWarehouseId <= 0) {

        alert("Please enter the destination warehouse ID.");

        return;
    }


    if (fromWarehouseId === toWarehouseId) {

        alert(
            "Source and destination warehouses must be different."
        );

        return;
    }


    if (!quantity || quantity <= 0) {

        alert("Please enter a valid quantity.");

        return;
    }


    try {

        const response = await fetch(
            "http://127.0.0.1:8000/api/stock",
            {
                method: "POST",

                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${token}`
                },

                body: JSON.stringify({

                    product_id: productId,

                    warehouse_id: toWarehouseId,

                    staff_id: 1,

                    transaction_type: "Stock Transfer",

                    quantity: quantity,

                    from_warehouse_id: fromWarehouseId,

                    remarks:
                        remarks ||
                        `Transferred from warehouse ${fromWarehouseId} to warehouse ${toWarehouseId}`

                })
            }
        );


        const data = await response.json();


        if (response.status === 401) {

            localStorage.removeItem("accessToken");
            localStorage.removeItem("adminLoggedIn");
            localStorage.removeItem("userRole");

            window.location.href = "adminlogin.html";

            return;
        }


        if (!response.ok) {

            console.error(
                "Stock Transfer API Error:",
                data
            );

            alert(
                data.detail ||
                "Unable to record Stock Transfer."
            );

            return;
        }


        alert(
            "Stock Transfer recorded successfully!"
        );


        showStockTransferPage();


    } catch (error) {

        console.error(
            "Stock Transfer Error:",
            error
        );

        alert(
            "Unable to connect to the backend."
        );
    }
}

// ============================================================
// 27. REPORTS
// ============================================================

function showReportsPage() {

    const content = getAdminContentArea();

    if (!content) return;

    hideOriginalAdminContent();

    const token = localStorage.getItem("accessToken");

    if (!token) {
        alert("Please login again.");
        window.location.href = "adminlogin.html";
        return;
    }

    content.innerHTML = `
        <div class="panel">

            <h2>📈 Reports</h2>

            <p>
                Total Products:
                <strong id="reportTotalProducts">
                    Loading...
                </strong>
            </p>

            <p>
                Total Available Quantity:
                <strong id="reportTotalQuantity">
                    Loading...
                </strong>
            </p>

            <p>
                Total Stock Transactions:
                <strong id="reportTotalTransactions">
                    Loading...
                </strong>
            </p>

            <p>
                Total Orders:
                <strong id="reportTotalOrders">
                    Loading...
                </strong>
            </p>

        </div>
    `;

    Promise.all([
        fetch("http://127.0.0.1:8000/api/products", {
            headers: {
                "Authorization": `Bearer ${token}`
            }
        }),

        fetch("http://127.0.0.1:8000/api/stock", {
            headers: {
                "Authorization": `Bearer ${token}`
            }
        }),

        fetch("http://127.0.0.1:8000/api/orders", {
            headers: {
                "Authorization": `Bearer ${token}`
            }
        })
    ])
    .then(async function (responses) {

        for (const response of responses) {

            if (response.status === 401) {
                localStorage.removeItem("accessToken");
                localStorage.removeItem("adminLoggedIn");
                localStorage.removeItem("userRole");

                alert("Session expired. Please login again.");
                window.location.href = "adminlogin.html";
                return;
            }

            if (!response.ok) {
                throw new Error("Failed to load report data.");
            }
        }

        const productsData = await responses[0].json();
        const stockData = await responses[1].json();
        const ordersData = await responses[2].json();

        const products =
            productsData.products || [];

        const transactions =
            stockData.transactions || [];

        const orders =
            ordersData.orders || [];

        const totalQuantity =
            products.reduce(
                function (total, product) {

                    return (
                        total +
                        Number(product.quantity || 0)
                    );

                },
                0
            );

        document.getElementById(
            "reportTotalProducts"
        ).textContent = products.length;

        document.getElementById(
            "reportTotalQuantity"
        ).textContent = totalQuantity;

        document.getElementById(
            "reportTotalTransactions"
        ).textContent = transactions.length;

        document.getElementById(
            "reportTotalOrders"
        ).textContent = orders.length;
    })
    .catch(function (error) {

        console.error("Reports error:", error);

        document.getElementById(
            "reportTotalProducts"
        ).textContent = "Error";

        document.getElementById(
            "reportTotalQuantity"
        ).textContent = "Error";

        document.getElementById(
            "reportTotalTransactions"
        ).textContent = "Error";

        document.getElementById(
            "reportTotalOrders"
        ).textContent = "Error";

        alert("Unable to load reports from backend.");
    });
}

// ============================================================
// 28. SETTINGS
// ============================================================

function showSettingsPage() {

    const content = getAdminContentArea();

    if (!content) return;

    hideOriginalAdminContent();

    const token = localStorage.getItem("accessToken");

    if (!token) {
        alert("Please login again.");
        window.location.href = "adminlogin.html";
        return;
    }

    content.innerHTML = `

        <div class="panel">

            <h2>⚙️ Settings</h2>

            <p>
                System Name:
                <strong id="settingsSystemName">
                    Loading...
                </strong>
            </p>

            <p>
                Low Stock Limit:
                <strong id="settingsLowStock">
                    Loading...
                </strong>
            </p>

        </div>
    `;

    fetch("http://127.0.0.1:8000/api/settings", {
        method: "GET",
        headers: {
            "Authorization": `Bearer ${token}`
        }
    })
    .then(async function (response) {

        if (response.status === 401) {

            localStorage.removeItem("accessToken");
            localStorage.removeItem("adminLoggedIn");
            localStorage.removeItem("userRole");

            alert("Session expired. Please login again.");
            window.location.href = "adminlogin.html";

            return null;
        }

        if (!response.ok) {
            throw new Error("Failed to load settings.");
        }

        return await response.json();
    })
    .then(function (data) {

        if (!data) return;

        console.log("Settings data:", data);

        const settings = data.settings || data;

        document.getElementById(
            "settingsSystemName"
        ).textContent =
            settings.system_name ||
            settings.systemName ||
            "Inventory & Warehouse Management System";

        document.getElementById(
            "settingsLowStock"
        ).textContent =
            Number(
                settings.low_stock_limit ||
                settings.lowStock ||
                10
            );
    })
    .catch(function (error) {

        console.error("Settings error:", error);

        document.getElementById(
            "settingsSystemName"
        ).textContent = "Error";

        document.getElementById(
            "settingsLowStock"
        ).textContent = "Error";

        alert("Unable to load settings from backend.");
    });
}


// ============================================================
// 29. STAFF NAVIGATION & PAGES (NEWLY ADDED)
// ============================================================

function setupStaffNavigation() {
    const links = document.querySelectorAll(".sidebar nav a");
    if (!links.length) return;

    links.forEach(function (link) {
        link.addEventListener("click", function (event) {
            event.preventDefault();
            links.forEach(function (item) {
                item.classList.remove("active");
            });
            link.classList.add("active");

            const text = link.textContent.trim().toLowerCase();

            if (text.includes("dashboard")) {
                showStaffDashboard();
            } else if (text.includes("products")) {
                showStaffProductsPage();
            } else if (text.includes("inventory")) {
                showStaffInventoryPage();
            } else if (text.includes("stock in")) {
                showStaffStockInPage();
            } else if (text.includes("stock out")) {
                showStaffStockOutPage();
            } else if (text.includes("orders")) {
                showStaffOrdersPage();
            } else if (text.includes("profile")) {
                showStaffProfilePage();
            }
        });
    });
}

function getStaffContentArea() {
    const main = document.querySelector(".main-content");
    if (!main) return null;

    let content = document.getElementById("staffAppContent");
    if (!content) {
        content = document.createElement("div");
        content.id = "staffAppContent";
        const topbar = main.querySelector(".topbar");
        if (topbar) {
            topbar.insertAdjacentElement("afterend", content);
        } else {
            main.appendChild(content);
        }
    }
    return content;
}

function hideOriginalStaffContent() {
    const main = document.querySelector(".main-content");
    if (!main) return;

    main.querySelectorAll(".cards, .dashboard-grid").forEach(function (section) {
        if (!section.closest("#staffAppContent")) {
            section.style.display = "none";
        }
    });
}

function showStaffDashboard() {
    const content = getStaffContentArea();
    if (!content) return;

    hideOriginalStaffContent();

    content.innerHTML = `
        <section class="cards">
            <div class="card">
                <div class="card-icon">📦</div>
                <div>
                    <h3 id="staffTotalProducts">0</h3>
                    <p>Total Products</p>
                </div>
            </div>
            <div class="card">
                <div class="card-icon">📋</div>
                <div>
                    <h3 id="staffAvailableStock">0</h3>
                    <p>Available Stock</p>
                </div>
            </div>
            <div class="card">
                <div class="card-icon">📥</div>
                <div>
                    <h3 id="staffStockInCount">0</h3>
                    <p>Stock In</p>
                </div>
            </div>
            <div class="card">
                <div class="card-icon">📤</div>
                <div>
                    <h3 id="staffStockOutCount">0</h3>
                    <p>Stock Out</p>
                </div>
            </div>
        </section>

        <section class="dashboard-grid">
            <div class="panel">
                <h2>Recent Activity</h2>
                <div style="overflow-x:auto;">
                    <table>
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Activity</th>
                                <th>Quantity</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody id="staffActivityTable"></tbody>
                    </table>
                </div>
            </div>
            <div class="panel">
                <h2>Low Stock</h2>
                <div class="low-stock" id="staffLowStockList"></div>
            </div>
        </section>
    `;

    updateStaffDashboard();
}

function updateStaffDashboard() {
    const products = getProducts();
    const transactions = getTransactions();
    const settings = getSettings();
    const lowLimit = Number(settings.lowStock || 10);
    const lowStockProducts = products.filter(p => Number(p.quantity) <= lowLimit);
    const totalQty = products.reduce((acc, p) => acc + Number(p.quantity || 0), 0);

    const totalProductsEl = document.getElementById("staffTotalProducts");
    const availStockEl = document.getElementById("staffAvailableStock");
    const stockInEl = document.getElementById("staffStockInCount");
    const stockOutEl = document.getElementById("staffStockOutCount");

    if (totalProductsEl) totalProductsEl.textContent = products.length;
    if (availStockEl) availStockEl.textContent = totalQty;

    const stockInTrans = transactions.filter(t => t.type === "Stock In");
    const stockOutTrans = transactions.filter(t => t.type === "Stock Out");
    if (stockInEl) stockInEl.textContent = stockInTrans.length;
    if (stockOutEl) stockOutEl.textContent = stockOutTrans.length;

    const activityTable = document.getElementById("staffActivityTable");
    if (activityTable) {
        const recent = transactions.slice().reverse().slice(0, 8);
        if (!recent.length) {
            activityTable.innerHTML = `<tr><td colspan="4" style="text-align:center;">No activity recorded yet.</td></tr>`;
        } else {
            activityTable.innerHTML = recent.map(item => `
                <tr>
                    <td>${escapeHTML(item.product)}</td>
                    <td>${escapeHTML(item.type)}</td>
                    <td>${Number(item.quantity || 0)}</td>
                    <td>${escapeHTML(item.date)}</td>
                </tr>
            `).join("");
        }
    }

    const lowStockList = document.getElementById("staffLowStockList");
    if (lowStockList) {
        if (!lowStockProducts.length) {
            lowStockList.innerHTML = `<p>✅ No low stock products.</p>`;
        } else {
            lowStockList.innerHTML = lowStockProducts.map(p => `
                <p>⚠️ ${escapeHTML(p.name)} <strong>${Number(p.quantity || 0)} left</strong></p>
            `).join("");
        }
    }
}

function showStaffProductsPage() {
    const products = getProducts();
    const content = getStaffContentArea();
    if (!content) return;
    hideOriginalStaffContent();

    content.innerHTML = `
        <div class="panel">
            <h2>📦 Products</h2>
            <div style="overflow-x:auto;">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Warehouse</th>
                            <th>Quantity</th>
                            <th>Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${products.map(p => `
                            <tr>
                                <td>${escapeHTML(p.id)}</td>
                                <td>${escapeHTML(p.name)}</td>
                                <td>${escapeHTML(p.category)}</td>
                                <td>${escapeHTML(p.warehouse)}</td>
                                <td>${Number(p.quantity || 0)}</td>
                                <td>${money(p.price)}</td>
                            </tr>
                        `).join("")}
                    </tbody>
                </table>
            </div>
        </div>
    `;
}

function showStaffInventoryPage() {
    showStaffProductsPage();
}

function showStaffStockInPage() {
    const content = getStaffContentArea();
    if (!content) return;
    hideOriginalStaffContent();

    content.innerHTML = `
        <div class="panel">
            <h2>📥 Stock In Operations</h2>
            <p>Record incoming shipments of products into inventory.</p>
            <div style="margin-top:20px; max-width:500px;">
                <div class="form-group" style="margin-bottom:15px;">
                    <label>Select Product</label>
                    <select id="staffStockInProd" class="input-wrapper" style="width:100%; height:45px;">
                        ${getProducts().map(p => `<option value="${escapeHTML(p.name)}">${escapeHTML(p.name)} (${escapeHTML(p.warehouse)})</option>`).join("")}
                    </select>
                </div>
                <div class="form-group" style="margin-bottom:15px;">
                    <label>Quantity to Add</label>
                    <input type="number" id="staffStockInQty" placeholder="Enter quantity" min="1" class="input-wrapper" style="width:100%; height:45px;">
                </div>
                <button class="save-btn" onclick="executeStaffStockIn()">Submit Stock In</button>
            </div>
        </div>
    `;
}

function executeStaffStockIn() {
    const prodName = document.getElementById("staffStockInProd").value;
    const qty = Number(document.getElementById("staffStockInQty").value);
    if (!qty || qty <= 0) {
        alert("Please enter a valid quantity.");
        return;
    }
    const products = getProducts();
    const product = products.find(p => p.name === prodName);
    if (product) {
        product.quantity = Number(product.quantity || 0) + qty;
        saveData("products", products);

        const transactions = getTransactions();
        transactions.push({
            product: product.name,
            type: "Stock In",
            quantity: qty,
            date: today()
        });
        saveData("transactions", transactions);

        alert("Stock In recorded successfully!");
        showStaffStockInPage();
    }
}

function showStaffStockOutPage() {
    const content = getStaffContentArea();
    if (!content) return;
    hideOriginalStaffContent();

    content.innerHTML = `
        <div class="panel">
            <h2>📤 Stock Out Operations</h2>
            <p>Dispatch products out of the inventory.</p>
            <div style="margin-top:20px; max-width:500px;">
                <div class="form-group" style="margin-bottom:15px;">
                    <label>Select Product</label>
                    <select id="staffStockOutProd" class="input-wrapper" style="width:100%; height:45px;">
                        ${getProducts().map(p => `<option value="${escapeHTML(p.name)}">${escapeHTML(p.name)} (Available: ${p.quantity})</option>`).join("")}
                    </select>
                </div>
                <div class="form-group" style="margin-bottom:15px;">
                    <label>Quantity to Dispatch</label>
                    <input type="number" id="staffStockOutQty" placeholder="Enter quantity" min="1" class="input-wrapper" style="width:100%; height:45px;">
                </div>
                <button class="delete-btn" onclick="executeStaffStockOut()">Submit Stock Out</button>
            </div>
        </div>
    `;
}

function executeStaffStockOut() {
    const prodName = document.getElementById("staffStockOutProd").value;
    const qty = Number(document.getElementById("staffStockOutQty").value);
    if (!qty || qty <= 0) {
        alert("Please enter a valid quantity.");
        return;
    }
    const products = getProducts();
    const product = products.find(p => p.name === prodName);
    if (product) {
        if (Number(product.quantity || 0) < qty) {
            alert("Insufficient quantity available in stock!");
            return;
        }
        product.quantity = Number(product.quantity || 0) - qty;
        saveData("products", products);

        const transactions = getTransactions();
        transactions.push({
            product: product.name,
            type: "Stock Out",
            quantity: qty,
            date: today()
        });
        saveData("transactions", transactions);

        alert("Stock Out recorded successfully!");
        showStaffStockOutPage();
    }
}

function showStaffOrdersPage() {
    const orders = getOrders();
    const content = getStaffContentArea();
    if (!content) return;
    hideOriginalStaffContent();

    content.innerHTML = `
        <div class="panel">
            <h2>🛒 Assigned Orders</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Product</th>
                        <th>Quantity</th>
                        <th>Customer</th>
                        <th>Status</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    ${orders.map(o => `
                        <tr>
                            <td>${escapeHTML(o.id)}</td>
                            <td>${escapeHTML(o.product)}</td>
                            <td>${Number(o.quantity || 0)}</td>
                            <td>${escapeHTML(o.customer)}</td>
                            <td>${escapeHTML(o.status)}</td>
                            <td>${escapeHTML(o.date)}</td>
                        </tr>
                    `).join("")}
                </tbody>
            </table>
        </div>
    `;
}

function showStaffProfilePage() {
    const staffId = localStorage.getItem("currentStaffId") || "STAFF001";
    const staffList = getStaff();
    const member = staffList.find(s => s.id === staffId) || {
        id: staffId,
        name: "Staff Member",
        phone: "9876543210",
        email: "staff@example.com",
        warehouse: "Hyderabad Warehouse",
        status: "Active"
    };

    const content = getStaffContentArea();
    if (!content) return;
    hideOriginalStaffContent();

    content.innerHTML = `
        <div class="panel">
            <h2>👤 Staff Profile</h2>
            <p><strong>Staff ID:</strong> ${escapeHTML(member.id)}</p>
            <p><strong>Name:</strong> ${escapeHTML(member.name)}</p>
            <p><strong>Phone:</strong> ${escapeHTML(member.phone)}</p>
            <p><strong>Email:</strong> ${escapeHTML(member.email)}</p>
            <p><strong>Assigned Warehouse:</strong> ${escapeHTML(member.warehouse)}</p>
            <p><strong>Status:</strong> ${escapeHTML(member.status)}</p>
        </div>
    `;
}
function checkAdminAuthentication() {

    const token = localStorage.getItem("accessToken");
    const role = localStorage.getItem("userRole");

    if (!token || role !== "admin") {
        window.location.href = "adminlogin.html";
        return false;
    }

    return true;
}


// ============================================================
// 30. INITIALIZATION
// ============================================================

document.addEventListener(
    "DOMContentLoaded",
    function () {

        setupAdminLogin();

        setupStaffLogin();


        const body =
            document.body;

        if (
            body &&
            body.classList.contains(
                "dashboard-body"
            )
        ) {

            const title =
                document.title
                    .toLowerCase();

if (
    title.includes("admin")
) {

    if (!checkAdminAuthentication()) {
        return;
    }

    setupAdminNavigation();

    showAdminDashboard();

} else if (
    title.includes("staff")
) {

    setupStaffNavigation();

    showStaffDashboard();

}
            
        }

    }
);